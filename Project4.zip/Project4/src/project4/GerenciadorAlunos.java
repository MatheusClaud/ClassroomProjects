package project4;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class GerenciadorAlunos {
	
	private Map <String, Aluno> alunos;
	private Scanner s;
	
	public GerenciadorAlunos() {
	
		alunos = new HashMap<String, Aluno>();
		s = new Scanner(System.in);
	}
	
	private void ExibeMenu() {
		System.out.println("(C)adastrar Aluno");
		System.out.println("(E)xibir Aluno");
		System.out.println("(N)ovo Grupo");
		System.out.println("(A)locar Aluno no Grupo e Imprimir Grupos");
		System.out.println("(R)egistrar Aluno que Respondeu");
		System.out.println("(I)mprimir Alunos que Responderam");
		System.out.println("(O)ra vamos fechar o progama!");
		System.out.print("Opção>");

	}
	
	private void cadastroAluno() {
		System.out.print("Matrícula: ");
		String matricula = s.next();
		
		System.out.print("Nome: ");
		String nome = s.next();
		
		System.out.print("Curso: ");
		String curso = s.next();
		
		if(alunos.containsKey(matricula)) {
			System.out.println("MATRÍCULA JÁ CADASTRADA!");
		}
		else {
			Aluno aluno = new Aluno(nome, curso, matricula);
			alunos.put(matricula, aluno);
			System.out.println("CADASTRO REALIZADO!");
		}
	}
	
	private void exibiAluno() {
		
		System.out.print("Matrícula: ");
		String matricula = s.next();
		
		if(alunos.containsKey(matricula)) {
			System.out.println("Aluno não cadastrado.");
		}
		else {
			Aluno aluno =alunos.get(matricula);
			System.out.println(aluno);
		}
		
	}
	
	public void rodar() {
		while (true) {
			this.ExibeMenu();
			String resposta;
			resposta = s.nextLine();
			
			if (resposta.equals("C")) this.cadastroAluno();
			else if (resposta.equals("E")) this.exibiAluno();
			else if (resposta.equals("O")) break;
		}
	}

}
