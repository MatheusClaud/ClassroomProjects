package project4;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class GerenciadorAlunos {
	
	private Map <String, Aluno> alunos;
	private Map <String, Grupos> grupos;
	private ArrayList <Aluno> alunosResponderam;
	private Scanner s;
	
	public GerenciadorAlunos() {
	
		alunos = new HashMap<String, Aluno>();
		grupos = new HashMap<String ,Grupos>();
		alunosResponderam = new ArrayList();
		s = new Scanner(System.in);
	}
	
	private void ExibeMenu() {
		System.out.println("(C)adastrar Aluno");
		System.out.println("(E)xibir Aluno");
		System.out.println("(N)ovo Grupo");
		System.out.println("(A)locar Aluno no Grupo e Imprimir Grupos");
		System.out.println("(R)egistrar Aluno que Respondeu");
		System.out.println("(I)mprimir Alunos que Responderam");
		System.out.println("(O)ra vamos fechar o progama!");
		System.out.print("Opção>");

	}
	
	private void cadastroAluno() {
		System.out.print("Matrícula: ");
		String matricula = s.next();
		
		System.out.print("Nome: ");
		String nome = s.next();
		
		System.out.print("Curso: ");
		String curso = s.next();
		
		if(alunos.containsKey(matricula)) {
			System.out.println("MATRÍCULA JÁ CADASTRADA!");
		}
		else {
			Aluno aluno = new Aluno(nome, curso, matricula);
			alunos.put(matricula, aluno);
			System.out.println("CADASTRO REALIZADO!");
		}
	}
	
	private void exibiAluno() {
		
		System.out.print("Matrícula: ");
		String matricula = s.next();
		
		if(alunos.containsKey(matricula)) {
			System.out.println("Aluno não cadastrado.");
		}
		else {
			Aluno aluno =alunos.get(matricula);
			System.out.println(aluno);
		}
		
	}
	
	private void cadastroGrupo() {
		System.out.print("Grupo: ");
		String nomeGrupo = s.next();
		
		if (grupos.containsKey(nomeGrupo)){
			System.out.println("GRUPO JÁ CADASTRADO!");
			return;
		}
		
		Grupos grupo = new Grupos(nomeGrupo);
		grupos.put(nomeGrupo, grupo);
		System.out.println("CADASTRO REALIZADO!");
	}
	
	private void manipulaGrupos() {
		
		String resposta = "";
		
		System.out.print("(A)locar Aluno ou (I)mprimir Grupo?");
		resposta = s.next();
		
		boolean cond1 = resposta.equals("A");
		boolean cond2 = resposta.equals("I");

		
		if (cond1) {
			
			System.out.print("Matricula: ");
			String matriculaAluno = s.next();
			
			if (!alunos.containsKey(matriculaAluno)) {
				System.out.println("Aluno não cadastrado.");
				return;
			}
			
			
			System.out.print("Grupo: ");
			String nomeGrupo = s.next();
			
			if (!grupos.containsKey(nomeGrupo)) {
				System.out.println("Grupo não cadastrado.");
				return;
			}
			
			
			grupos.get(nomeGrupo).setAlunoGrupo(alunos.get(matriculaAluno));
			alunos.get(matriculaAluno).setGrupo(grupos.get(nomeGrupo));
			System.out.println("ALUNO ALOCADO!");
		}
		
		else if (cond2) {
			
			System.out.print("Grupo: ");
			String nomeGrupo = s.next();
			
			if (!grupos.containsKey(nomeGrupo)) {
				System.out.println("Grupo não cadastrado.");
				return;
			}
			
			HashSet<Aluno> alunosGrupo = grupos.get(nomeGrupo).getAlunosGrupo();
			Iterator <Aluno> i = alunosGrupo.iterator();
			
			while(i.hasNext()) {
				System.out.println("* "+i.next().toString());
			}
		}
		
		
	}
	
	public void cadastroAlunoRespondeu() {
		
		System.out.print("Matricula: ");
		String matriculaAluno = s.next();
		
		if (!alunos.containsKey(matriculaAluno)) {
			System.out.println("Aluno não cadastrado.");
			return;
		}
		
		alunosResponderam.add(alunos.get(matriculaAluno));
		
		System.out.println("ALUNO REGISTRADO!");
		
	}
	
	public void exibeAlunosResponderam() {
		
		System.out.print("Alunos: ");		
		Iterator <Aluno> i = alunosResponderam.iterator();
		
		while(i.hasNext()) {
			System.out.println("* "+i.next().toString());
		}
	}
	
	public void rodar() {
		while (true) {
			this.ExibeMenu();
			String resposta;
			resposta = s.nextLine();
			
			if (resposta.equals("C")) this.cadastroAluno();
			else if (resposta.equals("E")) this.exibiAluno();
			else if (resposta.equals("N")) this.cadastroGrupo();
			else if (resposta.equals("A")) this.manipulaGrupos();
			else if (resposta.equals("R")) this.cadastroAlunoRespondeu();
			else if (resposta.equals("I")) this.exibeAlunosResponderam();
			else if (resposta.equals("O")) break;
		}
	}

}
