package project4;

import java.util.HashSet;

public class Aluno {
	
	private String nome;
	private String curso;
	private String matricula;
	private HashSet<Grupos> grupos;
	
	public Aluno(String nome, String curso, String matricula) {
		this.nome = nome;
		this.curso = curso;
		this.matricula = matricula;
		this.grupos = new HashSet<Grupos>();
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public String getCurso() {
		return this.curso;
	}
	
	public String getMatricula() {
		return this.matricula;
	}
	
	public void setGrupo(Grupos grupo) {
		this.grupos.add(grupo);
	}
	
	@Override
	public String toString() {
		return 	"Aluno: "+this.matricula+" - "+this.nome+" - "+this.curso;
	}
	
	@Override
	public boolean equals(Object obg) {
		
		if (!(this instanceof Object)) {
			return false;
		}
		
		Aluno o = (Aluno) obg;
		
		return this.matricula == o.getMatricula();
	}
}
