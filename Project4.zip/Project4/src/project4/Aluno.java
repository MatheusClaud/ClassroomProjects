package project4;

public class Aluno {
	
	private String nome;
	private String curso;
	private String matricula;
	
	public Aluno(String nome, String curso, String matricula) {
		this.nome = nome;
		this.curso = curso;
		this.matricula = matricula;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public String getCurso() {
		return this.curso;
	}
	
	public String getMatricula() {
		return this.matricula;
	}
	
	@Override
	public String toString() {
		return 	"Aluno: "+this.matricula+" - "+this.nome+" - "+this.curso;
	}
}
