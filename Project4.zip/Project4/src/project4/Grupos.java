package project4;

import java.util.HashSet;

public class Grupos {
	
	private String nomeGrupo;
	private HashSet<Aluno> alunosGrupo;
	
	public Grupos(String nomeGrupo) {
		this.setNomeGrupo(nomeGrupo);
		this.alunosGrupo = new HashSet<Aluno>();
	}

	public String getNomeGrupo() {
		return nomeGrupo;
	}

	public void setNomeGrupo(String nomeGrupo) {
		this.nomeGrupo = nomeGrupo;
	}
	
	public void setAlunoGrupo(Aluno aluno) {
		this.alunosGrupo.add(aluno);
	}
	
	public HashSet getAlunosGrupo() {
		return this.alunosGrupo;
	}
}
 