package project4;

public class Main {
	public static void main(String[] args) {
		GerenciadorAlunos ga = new GerenciadorAlunos();
		ga.rodar();
	}

}
