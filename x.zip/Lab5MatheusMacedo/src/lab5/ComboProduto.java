package lab5;

public class ComboProduto extends Produto {
	
	private double fatorDesconto;
	
	public ComboProduto(String nome, String descricao, Double preco, Double fator) {
		super(preco, nome, descricao);
		this.fatorDesconto = fator;
	}
	
	public void setFatorDescricao(double novoFator) {
		super.setPreco((super.getPreco() / (this.fatorDesconto * 100)) * (1 - novoFator));
		this.fatorDesconto = novoFator;
	}
	
	public double getFatorDesconto() {
		return this.fatorDesconto;
	}
	
	

}
