package lab5;

public class Compra {
	
	private String data;
	private String nomeProduto;
	private String descricaoProduto;
	private double preco;
	
	public Compra(String data, String nomeProduto, String descricaoProduto, double preco) {
		this.data = data;
		this.nomeProduto =nomeProduto;
		this.descricaoProduto = descricaoProduto;
		this.preco = preco;
	}
	
	public String getData() {
		return this.data;
	}

	public String getNomeProduto() {
		return this.nomeProduto;
	}

	public String getDescricaoProduto() {
		return this.descricaoProduto;
	}

	public double getPreco() {
		return this.preco;
	}

	
}
