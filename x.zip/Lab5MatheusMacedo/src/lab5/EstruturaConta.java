package lab5;

import java.util.HashMap;
import java.util.Map;

public class EstruturaConta {
	
	Map contas;
	
	public EstruturaConta() {
		contas = new HashMap<String, Conta>();
	}
	
	public void cadastraCompra(String nomeCliente, String nomeFornecedor, String data, String nomeProduto, String descricaoProduto, double preco) {
		
		if (!this.contas.containsKey(nomeFornecedor)) {
			Conta conta = new Conta();
			this.contas.put(nomeFornecedor, conta);
		}
		
		Conta c = (Conta) this.contas.get(nomeProduto);
		c.cadastraCompra(data, nomeProduto, descricaoProduto, preco, nomeCliente);
		
		
	}
}
