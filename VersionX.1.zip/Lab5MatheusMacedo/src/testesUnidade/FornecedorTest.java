package testesUnidade;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import lab5.Fornecedor;

public class FornecedorTest {
	
	@Test
	public void testCriacaoFornecedor() {
		
		Fornecedor f1 = new Fornecedor("nome", "telefone", "email");
		
		assertEquals(f1.getNome(), "nome");
		assertEquals(f1.getNumeroTelefone(), "telefone");
		assertEquals(f1.getEmail(), "email");
		
	}
	
	@Test
	public void testEquals() {
		
		Fornecedor f1 = new Fornecedor("nome", "telefone", "email");
		Fornecedor f2 = new Fornecedor("nome1", "telefone", "email");
		Fornecedor f3 = new Fornecedor("nome", "telefone1", "email1");
		
		assertFalse(f1.equals(f2));
		assertTrue(f1.equals(f3));
	}
	
	@Test
	public void testToString() {
		
		Fornecedor f1 = new Fornecedor("nome", "telefone", "email");
		assertEquals(f1.toString(), "nome - email - telefone");
	}

}
