package lab5;

import java.util.HashSet;
import java.util.Set;

import java.util.Iterator;

public class Conta {
	
	Set<Compra> contasFornecedores;
	private String nomeCliente;
	
	public Conta() {
		contasFornecedores = new HashSet<Compra>();
	}
	
	public void cadastraCompra(String data, String nomeProduto, String descricaoProduto, double preco, String nomeCliente) {
		Compra compra = new Compra(data, nomeProduto, descricaoProduto, preco);
		this.contasFornecedores.add(compra);
		this.nomeCliente = nomeCliente;
		
	}
	
	public Double getDebito() {
		Iterator <Compra> i = this.contasFornecedores.iterator();
		
		Double debito = 0.0;
		
		while(i.hasNext()) {
			debito += i.next().getPreco();
		}
		
		return debito;
	}
	
	public String getStringCompra() {
		Iterator <Compra> i = this.contasFornecedores.iterator();
		
		String saida = "";
		
		while(i.hasNext()) {
			Compra p = i.next();
			saida += p.getNomeProduto() + " - " + p.getData();
			
			if (i.hasNext()) {
				saida += " | ";
			}
		}
		
		return saida;
	}
	

}
