package lab5;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Controlador da estrutura conjunto de fornecedores.
 * Responsavel por regular e limitar a atribuicao e o acesso a dados de fornecedores.
 * O unico atributo que possui e o mapa de fornecedores.
 * 
 * @author Matheus Claudino
 */
public class EstruturaFornecedor {
	
	/**
	 * conjunto de forecedores, representados em formato de mapa
	 */
	private HashMap<String, Fornecedor> fornecedores;
	
	/**
	 * constroi o mapa como HashMap
	 */
	public EstruturaFornecedor() {
		this.fornecedores = new HashMap<String, Fornecedor>();
	}
	
	/**
	 * Retorna o mapa de fornecedores.
	 * 	  
	 * @return fornecedores
	 */
	public HashMap getFornecedores() {
		return this.fornecedores;
	}
	
	/**
	 * Metodo responsavel pela criacao de novos fornecedores e pela insercao deles no conjunto de fornecedores.
	 * Os novos fornecedores sao criados a partir dos valores passados como parametro.
	 * Retornna  o nome do fornecedor caso tenha sucesso na operacao.
	 * Nao e possivel repetir fornecedores.
	 * 
	   Lanca IllegalArgumentException caso nome, email ou numeroTelefone sejam nulos ou vazios.
	   Lanca IllegalArgumentException caso ja exista um mesmo fornecedor no conjunto de fornecedores.

	 * @param nome
	 * @param numeroTelefone
	 * @param email
	 * @return nome
	 */
	public String cadastroFornecedor(String nome, String numeroTelefone, String email) {
		
		if(nome == null || nome.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro do fornecedor: nome nao pode ser vazio ou nulo.");
		}
		
		if(email == null || email.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro do fornecedor: email nao pode ser vazio ou nulo.");
		}
		
		if(numeroTelefone == null || numeroTelefone.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro do fornecedor: telefone nao pode ser vazio ou nulo.");
		}
		
		if  (this.fornecedores.containsKey(nome)) {
			throw new IllegalArgumentException("Erro no cadastro de fornecedor: fornecedor ja existe.");
		}
		
		Fornecedor novoFornecedor = new Fornecedor(nome, numeroTelefone, email);
		
		this.fornecedores.put(nome, novoFornecedor);
		
		return nome;
	}
	
	/**
	 * Metodo responsavel por retornar a representacao textual de um fornecedor, identificado pelo nome.
	 * 
	 * Lanca IllegalArgumentException caso nome passado por parametro seja nulo, vazio ou nao referencie nenhum cliente.
	 * 
	 * @param nome
	 * @return
	 */
	public String getDadosFornecedor(String nome) {
		
		if (nome == null || nome.equals("")) {
			throw new IllegalArgumentException("Erro na exibicao do fornecedor: nome nao pode ser nulo ou vazio.");
		}
		
		if (!(this.fornecedores.containsKey(nome))) {
			throw new IllegalArgumentException("Erro na exibicao do fornecedor: fornecedor nao existe.");
		}
		
		return this.fornecedores.get(nome).toString();
		
	}
	
	/**
	 * Metodo responsavel por retirar um dado fornecedor identificado pelo nome do conjunto de fornecedores.
	 * 
	 * Lanca IllegalArgumentException caso nome passado por parametro seja nulo, vazio ou nao referencie nenhum cliente.
	 * 
	 * @param nome
	 */
	public void removeFornecedor(String nome) {
		if (nome == null || nome.equals("")) {
			throw new IllegalArgumentException("Erro na remocao do fornecedor: nome do fornecedor nao pode ser vazio ou nulo.");
		}
		
		if (!this.fornecedores.containsKey(nome)) {
			throw new IllegalArgumentException("Erro na remocao do fornecedor: fornecedor nao existe.");
		}
		
		this.fornecedores.remove(nome);
	}
	
	/**
	 * Metodo responsavel por retornar a representacao textual do todos os fornecedores no conjunto de fornecedores em ordem alfabetica por nome.
	 * Caso nao possua nenhum fornecedor cadastrado retorna "".
	 * Caso possua mais de um fornecedor cadastrado retorna as representacoes separadas por |.
	 * 
	 * @return representacao textual dos fornecedores
	 */
	public String getDadosTodosFornecedores() {
		
		Iterator<Fornecedor> i = this.fornecedores.values().iterator();
		ArrayList<Fornecedor> fornecedores = new ArrayList<Fornecedor>();
		
		while(i.hasNext()) {
			fornecedores.add(i.next());
		}
		
		Collections.sort(fornecedores, new Comparator() {
			public int compare(Object o1, Object o2) {
				Fornecedor f1 = (Fornecedor) o1;
				Fornecedor f2 = (Fornecedor) o2;
				
				return f1.getNome().compareTo(f2.getNome());
			}
		});
		
		String saida = "";
		i = fornecedores.iterator();
		while (i.hasNext()) {
			saida += i.next().toString();
			
			if (i.hasNext()) {
				saida += " | ";
			}
		}
		
		return saida;
	}
	
	/**
	 * Metodo responsavel por modificar dados dos fornecedores, a partir do nome e do valor que se deseja modificar.
	 * 
	 * Lanca IllegalArgumentException caso nome, valor ou novoValor sejam nulos ou vazios.
	   Lanca IllegalArgumentException caso ja exista um mesmo fornecedor no conjunto de fornecedores.
	   Lanca IllegalArgumentException valor nao seja: "telefone" ou "email".
	   
	 * @param nome
	 * @param valor
	 * @param novoValor
	 */
	public void editaDadosFornecedor(String nome, String valor, String novoValor) {
		
		if (nome == null || nome.equals("")) {
			throw new IllegalArgumentException("Erro na edicao do fornecedor: nome nao pode ser vazio ou nulo.");
		}
		
		if(nome == null || !(this.fornecedores.containsKey(nome))) {
			throw new IllegalArgumentException("Erro na edicao do fornecedor: fornecedor nao existe.");
		}
		
		if(valor == null || valor.equals("")) {
			throw new IllegalArgumentException("Erro na edicao do fornecedor: atributo nao pode ser vazio ou nulo.");
		}
		
		if(novoValor == null || novoValor.equals("")) {
			throw new IllegalArgumentException("Erro na edicao do fornecedor: novo valor nao pode ser vazio ou nulo.");
		}
		
		if (valor.equals("nome")){
			throw new IllegalArgumentException("Erro na edicao do fornecedor: nome nao pode ser editado.");
		}
		
		else if (valor.equals("telefone")){
			this.fornecedores.get(nome).setNumeroTelefone(novoValor);
		}
		
		else if (valor.equals("email")){
			this.fornecedores.get(nome).setEmail(novoValor);
		}
		
		else {
			throw new IllegalArgumentException("Erro na edicao do fornecedor: atributo nao existe.");
		}
	}
	
	/**
	 * Metodo responsavel por adicionar um produto a um fornecedor, a partir dos valores passados como parametro.
	 * 
	 * lanca IllegalArgumentException se nomeFornecedor for nulo, vazio ou nao referencie nunhum fornecedor.
	 * 
	 * @param nomeFornecedor
	 * @param preco
	 * @param nome
	 * @param descricao
	 */
	public void cadastroProdutoFornecedor(String nomeFornecedor, double preco, String nome, String descricao) {
		
		if (nomeFornecedor == null || nomeFornecedor.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro de produto: fornecedor nao pode ser vazio ou nulo.");
		}
		if (!this.fornecedores.containsKey(nomeFornecedor)) {
			throw new IllegalArgumentException("Erro no cadastro de produto: fornecedor nao existe.");
		}
		
		this.fornecedores.get(nomeFornecedor).adicionaProduto(preco, nome, descricao);
	}
	
	
	/**
	 * Metodo responsavel por recuperar a representacao textual de um produto, identificado por um nome e descricao, de um fornecedor idetificado por seu nome.
	 * 
	 * lanca IllegalArgumentException se nomeFornecedor for nulo, vazio ou nao referencie nunhum fornecedor.
	 * 
	 * @param nomeFornecedor
	 * @param nome
	 * @param descricao
	 * @return representacao textual de um produto
	 */
	public String getStringProdutoFornecedor(String nomeFornecedor, String nome, String descricao) {
		
		if (nomeFornecedor == null || nomeFornecedor.equals("")) {
			throw new IllegalArgumentException("Erro na exibicao de produto: fornecedor nao pode ser vazio ou nulo.");
		}
				
		if (!this.fornecedores.containsKey(nomeFornecedor)) {
			throw new IllegalArgumentException("Erro na exibicao de produto: fornecedor nao existe.");
		}
		
		return this.fornecedores.get(nomeFornecedor).getStringProduto(nome, descricao);
	}
	
	/**
	 * Metodo responsavel por recuperar a representacao textual de todos os produtos, de um fornecedor idetificado por seu nome.
	 * 
	 * lanca IllegalArgumentException se nomeFornecedor for nulo, vazio ou nao referencie nunhum fornecedor.
	 * Caso possua mais de um produto cadastrado retorna as representacoes separadas por |.

	 * 
	 * @param nomeFornecedor
	 * @return representacao textual de todos os produtos
	 */
	public String getStringTodosProdutosFornecedor(String nomeFornecedor) {
		
		if (nomeFornecedor == null || nomeFornecedor.equals("")) {
			throw new IllegalArgumentException("Erro na exibicao de produto: fornecedor nao pode ser vazio ou nulo.");
		}

		if (!this.fornecedores.containsKey(nomeFornecedor)) {
			throw new IllegalArgumentException("Erro na exibicao de produto: fornecedor nao existe.");
		}
		
		return this.fornecedores.get(nomeFornecedor).getStringTodosProdutos();
	}
	
	/**
	 * Metodo responsavel por recuperar a representacao textual de todos os produtos, de todos os fornecedores.
	 * 
	 * Caso possua mais de um produto cadastrado retorna as representacoes separadas por |.
	 * 
	 * @param nomeFornecedor
	 * @return representacao textual de todos os produtos
	 */
	public String getStringTodosProdutosTodosFornecedores() {
		
		Iterator<Fornecedor> fornecedores = this.fornecedores.values().iterator();
		
		ArrayList<Fornecedor> listaFornecedores = new ArrayList<Fornecedor>();
		
		while(fornecedores.hasNext()) {
			listaFornecedores.add(fornecedores.next());
		}
		
		Collections.sort(listaFornecedores, new Comparator() {
			public int compare(Object o1, Object o2) {
				Fornecedor f1 = (Fornecedor) o1;
				Fornecedor f2 = (Fornecedor) o2;
				
				return f1.getNome().compareTo(f2.getNome());
			}
		});
		
		String saida = "";
		
		fornecedores = listaFornecedores.iterator();
		
		while(fornecedores.hasNext()) {
						
			saida += fornecedores.next().getStringTodosProdutos();
			if (fornecedores.hasNext()) {
				saida += " | ";
			}
			
		}
		
		return saida;
	}
	
	/**
	 * Metodo responsavel por mudar o preco de um determinado produto identificado por um nome e uma descricao, de um dado fornecedor.
	 * 
	 * @param nomeFornecedor
	 * @param preco
	 * @param nome
	 * @param descricao
	 */
	public void editaPrecoProdutoFornecedor(String nomeFornecedor, double preco, String nome, String descricao) {
		
		if (nomeFornecedor == null || nomeFornecedor.equals("")) {
			throw new IllegalArgumentException("Erro na edicao de produto: fornecedor nao pode ser vazio ou nulo.");
		}
		
	
		if (!this.fornecedores.containsKey(nomeFornecedor)) {
			throw new IllegalArgumentException("Erro na edicao de produto: fornecedor nao existe.");
		}
		
		this.fornecedores.get(nomeFornecedor).editaPrecoProduto(preco, nome, descricao);
	}
	
	/**
	 * Metodo responsavel por remover um determinado produto identificado por um nome e uma descricao, de um dado fornecedor.
	   
	   lanca IllegalArgumentException se nomeFornecedor for nulo, vazio ou nao referencie nunhum fornecedor.
	 * 
	 * @param nome
	 * @param descricao
	 * @param nomeFornecedor
	 */
	public void removeProdutoFornecedor(String nome, String descricao, String nomeFornecedor) {
		
		if (nomeFornecedor == null || nomeFornecedor.equals("")) {
			throw new IllegalArgumentException("Erro na remocao de produto: fornecedor nao pode ser vazio ou nulo.");
		}
		
		if (!this.fornecedores.containsKey(nomeFornecedor)) {
			throw new IllegalArgumentException("Erro na remocao de produto: fornecedor nao existe.");
		}
		
		this.fornecedores.get(nomeFornecedor).removeProduto(nome, descricao);
	}
	
	public void cadastroComboProduto(String nomeFornecedor, String nomeCombo, String descricaoCombo, double fator, String produtos) {
		
		if (nomeFornecedor == null || nomeFornecedor.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro de combo: fornecedor nao pode ser vazio ou nulo.");
		}
		
		if (!this.fornecedores.containsKey(nomeFornecedor)) {
			throw new IllegalArgumentException("Erro no cadastro de combo: fornecedor nao existe.");
		}
		this.fornecedores.get(nomeFornecedor).adicionaComboProduto(descricaoCombo, nomeCombo, fator, produtos);
	}
	
}
