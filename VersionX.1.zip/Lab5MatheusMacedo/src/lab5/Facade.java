package lab5;

import easyaccept.EasyAccept;

/**
 * Representacao da "interface de comunicacao" das funcinalidades do front-end com as funcionalidades o back-end. 
 * 
 * @author Matheus Claudino
 */
public class Facade {
	
	/**
	 * controlador das funcionalidades relacionadas a cliente
	 */
	EstruturaCliente controlerCliente;
	
	/**
	 * controlador das funcionalidades relacionadas afornecedor e produto
	 */
	EstruturaFornecedor controlerFornecedor;
	
	/**
	 * Contrucão dos controlers
	 */
	public Facade() {
		controlerCliente = new EstruturaCliente();
		controlerFornecedor = new EstruturaFornecedor();
	}
	
	/**
	 * Invocacao dos casos de teste relacionados ao usuario.
	 * 
	 * @param args testes a serem efetuados
	 */
	public static void main(String[] args) {
		args = new String[] {"lab5.Facade", "acceptance_test/use_case_1.txt", "acceptance_test/use_case_2.txt", "acceptance_test/use_case_3.txt",  "acceptance_test/use_case_4.txt",  "acceptance_test/use_case_5.txt"};
		EasyAccept.main(args);
	}
	
	/**
	 * Realiza o cadastro de um cliente no sistema a partir de seu cpf, nome, email e localizacao.
	 * Caso cadastro ocorra com sucesso e retornado o cpf do cliente.
	 * Para ocorrer o cadastro com sucesso nenhuma das caracteristicas pode ser vazia ou nula e o cpf deve possuir 11 caracteres.
	 * 
	 * @param cpf
	 * @param nome
	 * @param email
	 * @param localizacao
	 * @return cpf do cliente.
	 */
	public String adicionaCliente(String cpf, String nome, String email, String localizacao) {
		return this.controlerCliente.cadastroCliente(cpf, nome, localizacao, email);
	}
	
	/**
	 * Retorna a representacao em string de um cliente caso as condicoes necessarias sejam satisfeitas.
	 * As condicoes necessarias sao: cpf passado por parametro nao nulo e nao vazio que referencie um cliente no sistema.
	 * 
	 * @param cpf
	 * @return representacao de um cliente
	 */
	public String exibeCliente(String cpf) {
		return this.controlerCliente.getDadosCliente(cpf);
	}
	
	/**
	 * Retorna a representacao de todos os clientes cadastrados no sistema.
	 * Caso tenha mais de uma representacao retornada elas serao separadas por : " | ".
	 * Caso nao seja retornada nenhuma representacao sera retornado: "".
	 * 
	 * @return representacao de todos os clientes cadastrados no sistema
	 */
	public String exibeClientes() {
		return this.controlerCliente.getDadosTodosClientes();
	}
	
	/**
	 * Permite a edicao de dados de um cliente cadastrado no sistema, desque o valor o qual se queira mudar seja existente e não seja o cpf.
	 * Para editar o nome de um cliente por exemplo se assume que valor == "nome".
	 * 
	 * @param cpf
	 * @param valor
	 * @param novoValor
	 */
	public void editaCliente(String cpf, String valor, String novoValor) {
		this.controlerCliente.editaDadosCliente(cpf, valor, novoValor);
	}
	
	/**
	 * Permite a remocao de um dado cliente, identificado pelo seu cpf, desque o cpf passado como parametro seja valido.
	 * Para o cpf seja valido e necessario que referencie um cliente no sistema.
	 * 
	 * @param cpf
	 */
	public void removeCliente(String cpf) {
		this.controlerCliente.removerCliente(cpf);
	}
	
	
	
	
	/**
	 * Realiza o cadastro de um fornecedor no sistema a partir de seu nome, email e numerotelefone.
	 * Caso cadastro ocorra com sucesso e retornado o nome do fornecedor.
	 * Para ocorrer o cadastro com sucesso nenhuma das caracteristicas pode ser vazia ou nula.
	 * 
	 * @param nome
	 * @param email
	 * @param numeroTelefone
	 * @return nome
	 */
	public String adicionaFornecedor(String nome, String email, String numeroTelefone) {
		return this.controlerFornecedor.cadastroFornecedor(nome, numeroTelefone, email);
	}
	
	/**
	 * Retorna a representacao em string de um fornecedor caso as condicoes necessarias sejam satisfeitas.
	 * As condicoes necessarias sao: nome passado por parametro nao nulo e nao vazio que referencie um fornecedor no sistema.
	 * 
	 * @param nome
	 * @return representacao em string de um fornecedor
	 */
	public String exibeFornecedor(String nome) {
		return this.controlerFornecedor.getDadosFornecedor(nome);
	}
	
	/**
	 * Retorna a representacao de todos os fornecedores cadastrados no sistema.
	 * Caso tenha mais de uma representacao retornada elas serao separadas por : " | ".
	 * Caso nao seja retornada nenhuma representacao sera retornado: "".
	 * 
	 * @return representacao de todos os fornecedores cadastrados no sistema
	 */
	public String exibeFornecedores() {
		return this.controlerFornecedor.getDadosTodosFornecedores();
	}
	
	/**
	 * Permite a edicao de dados de um fornecedor cadastrado no sistema, desque o valor o qual se queira mudar seja existente e não seja o nome.
	 * Para editar o email de um fornecedor por exemplo se assume que valor == "email".
	 * 
	 * @param nome
	 * @param valor
	 * @param novoValor
	 */
	public void editaFornecedor(String nome, String valor, String novoValor) {
		this.controlerFornecedor.editaDadosFornecedor(nome, valor, novoValor);
	}
	
	/**
	 * Permite a remocao de um dado fornecedor, identificado pelo seu nome, desque o nome passado como parametro seja valido.
	 * Para o nome seja valido e necessario que referencie um fornecedor cadastrado no sistema.
	 * 
	 * @param nome
	 */
	public void removeFornecedor(String nome) {
		this.controlerFornecedor.removeFornecedor(nome);
	}

	
	
	/**
	 * Realiza o cadastro de um produto para um deterinado fornecedor no sistema. a partir do nome, descricao e preco.
	 * Para ocorrer o cadastro com sucesso nenhuma das caracteristicas pode ser vazia ou nula, o nomeFornecedor deve referenciar algum fornecedor no sistema e nao pde ser um caracteristicas que sejam iguais as caracteristicas chave de um produto ja cadastrado.
	 * As caracteristicas chave de produto sao: nome e descricao.
	 * 
	 * @param nomeFornecedor
	 * @param nome
	 * @param descricao
	 * @param preco
	 */
	public void adicionaProduto(String nomeFornecedor, String nome, String descricao, Double preco) {
		this.controlerFornecedor.cadastroProdutoFornecedor(nomeFornecedor, preco, nome, descricao);

	}
	
	/**
	 * Retorna a representacao em string de um produto de um certo fornecedor, isto caso as condicoes necessarias sejam satisfeitas.
	 * As condicoes necessarias sao: nomeFornecedor passado por parametro nao nulo e nao vazio que referencie um fornecedor no sistema e um nome e descricao nao nulos e nao vazios que referenciem um produto do fornecedor em questao.
	 * 
	 * 
	 * @param nome
	 * @param descricao
	 * @param nomeFornecedor
	 * @return representacao em string de um produto de um certo fornecedor.
	 */
	public String exibeProduto(String nome, String descricao, String nomeFornecedor) {
		return this.controlerFornecedor.getStringProdutoFornecedor(nomeFornecedor, nome, descricao);
	}
	
	/**
	 * Retorna a representacao de todos produto de um certo fornecedor, isto caso as condicoes necessarias sejam satisfeitas.
	 * As condicoes necessarias sao: nomeFornecedor passado por parametro nao nulo e nao vazio que referencie um fornecedor no sistema.
	 * Caso tenha mais de uma representacao retornada elas serao separadas por : " | ".
	 * Caso nao seja retornada nenhuma representacao sera retornado: "".
	 * 
	 * @param nomeFornecedor
	 * @return representacao de todos produto de um certo fornecedor
	 */
	public String exibeProdutosFornecedor(String nomeFornecedor) {
		return this.controlerFornecedor.getStringTodosProdutosFornecedor(nomeFornecedor);
	}
	
	/**
	 * Retorna todas as representaoes de todos os produtos de todos os fornecedores no sistema.
	 * Caso tenha mais de uma representacao retornada elas serao separadas por : " | ".
	 * Caso nao seja retornada nenhuma representacao sera retornado: "".
	 * 
	 * @return representaoes de todos os produtos de todos os fornecedores no sistema
	 */
	public String exibeProdutos() {
		return this.controlerFornecedor.getStringTodosProdutosTodosFornecedores();
	} 
	
	/**
	 * Permite a edicao do preco de um certo produto pertencente a um certo fornecedor do sistema, isto se os requisitos forem cumpridos.
	 * As condicoes necessarias sao: nomeFornecedor passado por parametro nao nulo e nao vazio que referencie um fornecedor no sistema e que o produto referenciado exista no fornecedor especificado.
	 * Apenas o preco pode ser editado;
	 * 
	 * @param nome
	 * @param descricao
	 * @param nomeFornecedor
	 * @param preco
	 */
	public void editaProduto(String nome, String descricao, String nomeFornecedor, Double preco) {
		this.controlerFornecedor.editaPrecoProdutoFornecedor(nomeFornecedor, preco, nome, descricao);
	}
	
	/**
	 * Permite a remocao de um dado produto de um certo fornecedor, identificado pelo seu nome, desque o nomeFornecedor, nome e descricao passado como parametro seja valido..
	 * Para o nomeFornecedor seja valido e necessario que referencie um fornecedor cadastrado no sistema. 
	 * Para que nome e descricao sejam validos eles devem referenciar um produto do fornecedor especificado.
	 * 
	 * @param nomeFornecedor
	 * @param nome
	 * @param descricao
	 */
	public void removeProduto(String nomeFornecedor, String nome, String descricao) {
		this.controlerFornecedor.removeProdutoFornecedor(nomeFornecedor, nome, descricao);
	}
	
	public void adicionaCombo(String nomeFornecedor, String nomeCombo, String descricaoCombo, double fator, String produtos) {
		this.controlerFornecedor.cadastroComboProduto(nomeFornecedor, nomeCombo, descricaoCombo, fator, produtos);
	}
}

