package lab5;

import java.util.Iterator;

/**
 * Representacao de um fornecedor, todo fornecedor e identificado unicamente pelo seu nome.
 * Todo fornecedor deve possuir obrigatoriamete nome, numero de telefone e email.
 * @author Matheus Claudino
 */
public class Fornecedor {
	
	/**
	 * nome do fornecedor
	 */
	private String nome;
	
	/**
	 * numero telefonico do fornecedor
	 */
	private String numeroTelefone;
	
	/**
	 * email do fornecedor
	 */
	private String email;
	
	/**
	 * conjunto de produtos que o fornecedor oferece, n�o � obrigat�rio ser iniciado
	 */
	private EstruturaProduto listaProdutos;
	
	/**
	 * Controi um fornecedor a partir dos valores passados como parametro.
	 * O unico atributo nao iniciado e listaProdutos.
	 * @param nome
	 * @param numeroTelefone
	 * @param email
	 */
	public Fornecedor(String nome, String numeroTelefone, String email) {
		
		this.nome = nome;
		this.numeroTelefone = numeroTelefone;
		this.email = email;
		this.listaProdutos = new EstruturaProduto();
		
	}

	/**
	 * Recupera o nome do forecedor.
	 * 
	 * @return nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * Recupera o telefone do fornecedor
	 * 
	 * @return telefone
	 */
	public String getNumeroTelefone() {
		return numeroTelefone;
	}

	/**
	 * Modifica o telefone do fornecedor.
	 * 
	 * @param numeroTelefone novo numero telefonico
	 */
	public void setNumeroTelefone(String numeroTelefone) {
		this.numeroTelefone = numeroTelefone;
	}
	
	/**
	 * Recupera o email do fornecedor.
	 * 
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * Modifica o email do fornecedor.
	 * 
	 * @param email novo email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * Atribui um novo produto ao conjunto de produtos que o fornecedor oferece
	 * O novo produto � atribuido a partir de seu preco, nome e descricao.
	 * 
	 * @param preco
	 * @param nome
	 * @param descricao
	 */
	public void adicionaProduto(double preco, String nome, String descricao) {
		this.listaProdutos.cadastroProduto(preco, nome, descricao);
	}
	
	/**
	 * Recupera a representacao textual de um produto do fornecedor.
	 * O produto � identificado a partir de seu nome e descricao.
	 * 
	 * @param nome
	 * @param descricao
	 * @return representacao textual do produto
	 */
	public String getStringProduto(String nome, String descricao) {
		return this.listaProdutos.getStringProduto(nome, descricao);
	}
	
	
	/**
	 * Recupera a representacao textual de todos os produtos oferecidos por este fornecedor.
	 * Caso nao exista nenhum retornara ""
	 * Caso exista mais de um seguira o seguinte formato: descricao | descricao
	 * 
	 * @return representacao textual dos produtos
	 */
	public String getStringTodosProdutos() {

		Iterator lista= this.listaProdutos.getStringTodosProdutos().iterator();
		String saida = "";
		
		while (lista.hasNext()) {
			saida += this.nome + " - " + lista.next().toString();
			if(lista.hasNext()) {
				saida += " | ";
			}
		}
		
		return saida;		
	}
	
	/**
	 * Modifica o preco de um determinado produto oferecido pelo fornecedor.
	 * O produto � identificado por seu nome e descricao.
	 * 
	 * @param preco novo preco
	 * @param nome
	 * @param descricao
	 */
	public void editaPrecoProduto(double preco, String nome, String descricao) {
		this.listaProdutos.editaPrecoProduto(preco, nome, descricao);
	}

	/**
	 * Remove um determinado produto do conjunto que ele oferece.
	 * O produto � identificado por seu nome e descricao.
	 * 
	 * @param nome
	 * @param descricao
	 */
	public void removeProduto(String nome, String descricao) {
		this.listaProdutos.removeProduto(nome, descricao);
	}
	
	public void adicionaComboProduto(String descricao, String nome, double fator, String produtos) {
		this.listaProdutos.cadastroComboProduto(descricao, nome, fator, produtos);
	}
	
	/**
	 * Retorna a representacao textual do fornecedor no formato:
	 * nome - email - numeroTelefone
	 */
	@Override
	public String toString() {
		return this.nome + " - " + this.email + " - " + this.numeroTelefone; 
	}
	
	/**
	 * Compara este fornecedor com outro, e retorna o valor booleano da afirmacao: os dois sao iguais?
	 * A condicao de igualdade e os dois terem o mesmo nome.
	 */
	@Override
	public boolean equals(Object obj) {
		
		if (!(this instanceof Object)) {
			return false;
		}
		
		Fornecedor fornecedor = (Fornecedor) obj;
		return this.nome.equals(fornecedor.getNome());
	}
	
	
}
