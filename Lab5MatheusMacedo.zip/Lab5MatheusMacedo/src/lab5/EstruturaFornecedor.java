package lab5;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

public class EstruturaFornecedor {
	
	private HashMap<String, Fornecedor> fornecedores;
	
	public EstruturaFornecedor() {
		this.fornecedores = new HashMap<String, Fornecedor>();
	}
	
	public void cadastraFornecedor(String nome, String numeroTelefone, String email) {
		
		if (nome == null || numeroTelefone == null || email == null) {
			throw new IllegalArgumentException();
		}
		
		Fornecedor novoFornecedor = new Fornecedor(nome, numeroTelefone, email);
		
		this.fornecedores.put(nome, novoFornecedor);
	}
	
	public String getDadosFornecedor(String nome) {
		
		if (nome == null || this.fornecedores.containsKey(nome)) {
			throw new IllegalArgumentException();
		}
		
		return this.fornecedores.get(nome).toString();
		
	}
	
	public void removeFornecedor(String nome) {
		if (nome == null || this.fornecedores.containsKey(nome)) {
			throw new IllegalArgumentException();
		}
		
		this.fornecedores.remove(nome);
	}
	
	public String getDadosTodosFornecedores() {
		
		Iterator<Fornecedor> i = this.fornecedores.values().iterator();
		ArrayList<Fornecedor> fornecedores = new ArrayList<Fornecedor>();
		
		while(i.hasNext()) {
			fornecedores.add(i.next());
		}
		
		Collections.sort(fornecedores, new Comparator() {
			public int compare(Object o1, Object o2) {
				Fornecedor f1 = (Fornecedor) o1;
				Fornecedor f2 = (Fornecedor) o2;
				
				return f1.getNome().compareTo(f2.getNome());
			}
		});
		
		String saida = "";
		i = fornecedores.iterator();
		while (i.hasNext()) {
			saida += i.next().toString();
			
			if (i.hasNext()) {
				saida += " | ";
			}
		}
		
		return saida;
	}
	
	public void editaDadosFornecedor(String nome, String numeroTelefone, String email) {
		
		if (nome == null || this.fornecedores.containsKey(nome)) {
			throw new IllegalArgumentException();
		}
		
		this.fornecedores.get(nome).setEmail(email);
		this.fornecedores.get(nome).setNumeroTelefone(numeroTelefone);
	}
	

}
