package lab5;

public class Facade {
	
	EstruturaCliente ec;
	EstruturaFornecedor ef;
	
	public Facade() {
		ec = new EstruturaCliente();
		ef = new EstruturaFornecedor();
	}
	
	
	
	
	public String cadastroCliente(String cpf, String nome, String localizacao, String email) {
		return this.ec.cadastroCliente(cpf, nome, localizacao, email);
	}
	
	public String getDadosCliente(String cpf) {
		return this.ec.getDadosCliente(cpf);
	}
	
	public String getDadosTodosClientes() {
		return this.getDadosTodosClientes();
	}
	
	public void editaDadosCliente(String cpf, String nome, String localizacao, String email) {
		this.ec.editaDadosCliente(cpf, nome, localizacao, email);
	}
	
	public void removeCliente(String cpf) {
		this.ec.removerCliente(cpf);
	}
	
	
	
	
	public void cadastroFornecedor(String nome, String numeroTelefone, String email) {
		this.ef.cadastroFornecedor(nome, numeroTelefone, email);
	}
	
	public String getDadosFornecedor(String nome) {
		return this.ef.getDadosFornecedor(nome);
	}
	
	public String getDadosTodosFornecedores() {
		return this.ef.getDadosTodosFornecedores();
	}
	
	public void editaDasosFornecedor(String nome, String numeroTelefone, String email) {
		this.ef.editaDadosFornecedor(nome, numeroTelefone, email);
	}
	
	public void removeFornecedor(String nome) {
		this.ef.removeFornecedor(nome);
	}

	
	
	
	public void cadastraProdutoFornecedor(String nomeFornecedor, Double preco, String nome, String descricao) {
		this.ef.cadastroProdutoFornecedor(nomeFornecedor, preco, nome, descricao);

	}
	
	public String getStringProdutoFornecedor(String nomeFornecedor, String nome, String descricao) {
		return this.ef.getStringProdutoFornecedor(nomeFornecedor, nome, descricao);
	}
	
	public String getStringTodosProdutosFornecedor(String nomeFornecedor) {
		return this.ef.getStringTodosProdutosFornecedor(nomeFornecedor);
	}
	
	public String getStringTodosProdutosTodosFornecedores() {
		return this.ef.getStringTodosProdutosTodosFornecedores();
	} 
	
	public void editaPrecoProdutoFornecedor(String nomeFornecedor, Double preco, String nome, String descricao) {
		this.ef.editaPrecoProdutoFornecedor(nomeFornecedor, preco, nome, descricao);
	}
	
	public void editaProdutoFornecedor(String nomeFornecedor, Double preco, String nome, String descricao) {
		this.ef.editaProdutoFornecedor(nomeFornecedor, preco, nome, descricao);
	}
	
	public void removeProdutoFornecedor(String nomeFornecedor, String nome, String descricao) {
		this.ef.removeProdutoFornecedor(nomeFornecedor, nome, descricao);
	}
		
}

