package lab5;

import easyaccept.EasyAccept;

public class Facade {
	
	EstruturaCliente ec;
	EstruturaFornecedor ef;
	
	public Facade() {
		ec = new EstruturaCliente();
		ef = new EstruturaFornecedor();
	}
	
	public static void main(String[] args) {
		args = new String[] {"lab5.Facade", "acceptance_test/use_case_1.txt", "acceptance_test/use_case_2.txt", "acceptance_test/use_case_3.txt"};
		EasyAccept.main(args);
	}
	
	
	public String adicionaCliente(String cpf, String nome, String email, String localizacao) {
		return this.ec.cadastroCliente(cpf, nome, localizacao, email);
	}
	
	public String exibeCliente(String cpf) {
		return this.ec.getDadosCliente(cpf);
	}
	
	public String getDadosTodosClientes() {
		return this.getDadosTodosClientes();
	}
	
	public void editaCliente(String cpf, String valor, String novoValor) {
		this.ec.editaDadosCliente(cpf, valor, novoValor);
	}
	
	public void removeCliente(String cpf) {
		this.ec.removerCliente(cpf);
	}
	
	
	
	
	public String adicionaFornecedor(String nome, String email, String numeroTelefone) {
		return this.ef.cadastroFornecedor(nome, numeroTelefone, email);
	}
	
	public String exibeFornecedor(String nome) {
		return this.ef.getDadosFornecedor(nome);
	}
	
	public String getDadosTodosFornecedores() {
		return this.ef.getDadosTodosFornecedores();
	}
	
	public void editaFornecedor(String nome, String valor, String novoValor) {
		this.ef.editaDadosFornecedor(nome, valor, novoValor);
	}
	
	public void removeFornecedor(String nome) {
		this.ef.removeFornecedor(nome);
	}

	
	
	
	public void adicionaProduto(String nomeFornecedor, String nome, String descricao, Double preco) {
		this.ef.cadastroProdutoFornecedor(nomeFornecedor, preco, nome, descricao);

	}
	
	public String exibeProduto(String nome, String descricao, String nomeFornecedor) {
		return this.ef.getStringProdutoFornecedor(nomeFornecedor, nome, descricao);
	}
	
	public String getStringTodosProdutosFornecedor(String nomeFornecedor) {
		return this.ef.getStringTodosProdutosFornecedor(nomeFornecedor);
	}
	
	public String getStringTodosProdutosTodosFornecedores() {
		return this.ef.getStringTodosProdutosTodosFornecedores();
	} 
	
	public void editaProduto(String nome, String descricao, String nomeFornecedor, Double preco) {
		this.ef.editaPrecoProdutoFornecedor(nomeFornecedor, preco, nome, descricao);
	}
	
	
	public void removeProduto(String nomeFornecedor, String nome, String descricao) {
		this.ef.removeProdutoFornecedor(nomeFornecedor, nome, descricao);
	}
		
}

