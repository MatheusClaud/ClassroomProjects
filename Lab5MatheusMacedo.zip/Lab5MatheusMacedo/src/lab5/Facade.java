package lab5;

public class Facade {

}
