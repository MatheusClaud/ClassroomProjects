package lab5;

public class ChaveProduto {
	
	private String nome;
	private String descricao;
	
	public ChaveProduto(String nome, String descricao) {
		this.nome = nome;
		this.descricao = descricao;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public String getDescricao() {
		return this.descricao;
	}

	@Override
	public boolean equals(Object o) {
		if (!(this instanceof Object)) {
			throw new IllegalArgumentException();
		}
		
		ChaveProduto chave = (ChaveProduto) o;
		
		boolean cond1 = this.nome.equals(chave.getNome());
		boolean cond2 = this.descricao.equals(chave.getDescricao());
	
		return cond1 && cond2;
	}
	
	@Override
	public int hashCode() {
		return (this.nome + this.descricao).hashCode();
	}

}
