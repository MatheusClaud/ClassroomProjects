package lab5;

public class Cliente {
	
	private String cpf;
	private String nome;
	private String localizacao;
	private String email;

	public Cliente(String cpf, String nome, String localizacao, String email) {
		this.cpf = cpf;
		this.nome = nome;
		this.localizacao = localizacao;
		this.email = email;
	}

	public String getCpf() {
		return cpf;
	}

	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getLocalizacao() {
		return localizacao;
	}

	public String getEmail() {
		return email;
	}
	
	public void setLocalizacao(String localizacao) {
		this.localizacao = localizacao;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return this.nome + " - " + this.localizacao + " - " + this.email; 
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if (!(this instanceof Object)) {
			return false;
		}
		
		Cliente cliente = (Cliente) obj;
		return this.cpf.equals(cliente.getCpf());
	}
	
	
}
