package lab5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Controlador da estrutura conjunto de clientes.
 * Responsavel por regular e limitar a atribuicao e o acesso a dados de clientes.
 * O unico atributo que possui e o mapa de clientes.
 * 
 * @author Matheus Claudino
 */
public class EstruturaCliente {
	
	/**
	 * conjunto de clientes, representados em formato de mapa
	 */
	private HashMap<String, Cliente> clientes;
	
	/**
	 * constroi o mapa como HashMap
	 */
	public EstruturaCliente() {
		this.clientes = new HashMap();
	}
	
	/**
	 * Retorna o mapa de clientes
	 * 
	 * @return clientes
	 */
	public HashMap getClientes() {
		return this.clientes;
	}
	
	/**
	 * Metodo responsavel pela criacao de novos clientes e pela insercao deles no conjunto de clientes.
	 * Os novos clientes sao criados a partir dos valores passados como parametro.
	 * Retornna  o cpf do cliente caso tenha sucesso na operacao.
	 * Nao e possivel repetir clientes
	 * 
	   Lanca IllegalArgumentException caso nome, email ou localizacao sejam nulos ou vazios.
	   Lanca IllegalArgumentException caso ja exista um mesmo cliente no conjunto de clientes.
	   Lanca IllegalArgumentException caso cpf tenha tamanho menor que 11 ou seja nulo ou vazio.
	   
	 * @param cpf
	 * @param nome
	 * @param localizacao
	 * @param email
	 * @return cpf
	 */
	public String cadastroCliente(String cpf, String nome, String localizacao, String email) {
		
		if (cpf == null || cpf.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro do cliente: cpf nao pode ser vazio ou nulo.");
		}
		
		if (nome == null || nome.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro do cliente: nome nao pode ser vazio ou nulo.");
		}
		
		if (email == null || email.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro do cliente: email nao pode ser vazio ou nulo.");
		}
		
		if (localizacao == null || localizacao.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro do cliente: localizacao nao pode ser vazia ou nula.");
		}
		if(this.clientes.containsKey(cpf)) {
			throw new IllegalArgumentException("Erro no cadastro do cliente: cliente ja existe.");
		}
		
		if(cpf.length() != 11) {
			throw new IllegalArgumentException("Erro no cadastro do cliente: cpf invalido.");
		}
		
		Cliente novoCliente = new Cliente(cpf, nome, localizacao, email);
		this.clientes.put(cpf, novoCliente);
		return cpf;
		
	}
	
	
	/**
	 * Metodo responsavel por retirar um dado cliente identificado pelo cpf do conjunto de clientes.
	 * 
	 * Lanca IllegalArgumentException caso cpf passado por parametro seja nulo, vazio ou nao referencie nenhum cliente.
	 * 
	 * @param cpf
	 */
	public void removerCliente(String cpf) {
		
		if (cpf == null || cpf.equals("") ) {
			throw new IllegalArgumentException("Erro na remocao do cliente: cpf nao pode ser nulo ou vazio.");
		}
		
		if(!(this.clientes.containsKey(cpf))) {
			throw new IllegalArgumentException("Erro na remocao do cliente: cpf invalido.");
		}
		
		this.clientes.remove(cpf);
	}

	/**
	 * Metodo responsavel por retornar a representacao textual de um cliente, identificado pelo cpf.
	 * 
	 * Lanca IllegalArgumentException caso cpf passado por parametro seja nulo, vazio ou nao referencie nenhum cliente.
	 * 
	 * @param cpf
	 * @return representacao textual do cliente
	 */
	public String getDadosCliente(String cpf) {
		
		if (cpf == null || cpf.equals("") ) {
			throw new IllegalArgumentException("Erro na exibicao do cliente: cpf nao pode ser nulo ou vazio.");
		}
		if(!(this.clientes.containsKey(cpf))) {
			throw new IllegalArgumentException("Erro na exibicao do cliente: cliente nao existe.");
		}
		
		return this.clientes.get(cpf).toString();
	}
	
	/**
	 * Metodo responsavel por retornar a representacao textual do todos os clientes no conjunto de clientes, em ordem alfabetica por nome.
	 * Caso nao possua nenhum cliente cadastrado retorna "".
	 * Caso possua mais de um cliente cadastrado retorna as representacoes separadas por |.
	 * 
	 * @return representacao textual de todos clientes.
	 */
	public String getDadosTodosClientes() {
		
		Iterator<Cliente> i = this.clientes.values().iterator();
		ArrayList<Cliente> clientes = new ArrayList<Cliente>();
		
		while(i.hasNext()) {
			clientes.add(i.next());
		}
		
		Collections.sort(clientes, new Comparator() {
			public int compare(Object o1, Object o2) {
				Cliente c1 = (Cliente) o1;
				Cliente c2 = (Cliente) o2;
				
				return c1.getNome().compareTo(c2.getNome());
			}
		});
		
		String saida = "";
		i = clientes.iterator();
		while(i.hasNext()) {
			saida += i.next().toString();
			if (i.hasNext()) {
				saida += " | ";
			}
		}
		
		return saida;
	}
	
	/**
	 * Metodo responsavel por modificar dados dos clientes, a partir do cpf e do valor que se deseja modificar.
	 * 
	 * Lanca IllegalArgumentException caso cpf, nome, valor ou novoValor sejam nulos ou vazios.
	   Lanca IllegalArgumentException caso ja exista um mesmo cliente no conjunto de clientes.
	   Lanca IllegalArgumentException valor nao seja: "nome", "localizacao" ou "emaill".
	 * 
	 * @param cpf
	 * @param valor
	 * @param novoValor
	 */
	public void editaDadosCliente(String cpf, String valor, String novoValor) {
		
		if(!(this.clientes.containsKey(cpf))) {
			throw new IllegalArgumentException("Erro na edicao do cliente: cliente nao existe.");
		}
		
		if (cpf == null || cpf.equals("") ) {
			throw new IllegalArgumentException("Erro na edicao do cliente: cpf nao pode ser nulo ou vazio.");
		}
		
		if(valor == null || valor.equals("")) {
			throw new IllegalArgumentException("Erro na edicao do cliente: atributo nao pode ser vazio ou nulo.");
		}
		
		if(novoValor == null || novoValor.equals("")) {
			throw new IllegalArgumentException("Erro na edicao do cliente: novo valor nao pode ser vazio ou nulo.");
		}
		
		if (valor.equals("nome")){
			this.clientes.get(cpf).setNome(novoValor);
		}
		
		else if (valor.equals("localizacao")){
			this.clientes.get(cpf).setLocalizacao(novoValor);
		}
		
		else if (valor.equals("email")){
			this.clientes.get(cpf).setEmail(novoValor);
		}
		
		else {
			throw new IllegalArgumentException("Erro na edicao do cliente: atributo nao existe.");
		}
		
	}
	
	
}
