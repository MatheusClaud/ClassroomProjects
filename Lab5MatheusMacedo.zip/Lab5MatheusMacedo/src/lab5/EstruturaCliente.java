package lab5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;


public class EstruturaCliente {
	
	private HashMap<String, Cliente> clientes;
	
	public EstruturaCliente() {
		this.clientes = new HashMap();
	}
	
	public String cadastroCliente(String cpf, String nome, String localizacao, String email) {
		
		if(cpf == null || nome == null || localizacao == null || email == null) {
			throw new IllegalArgumentException();
		}
		
		Cliente novoCliente = new Cliente(cpf, nome, localizacao, email);
		this.clientes.put(cpf, novoCliente);
		return cpf;
		
	}
	
	public void removerCliente(String cpf) {
		
		if(cpf == null || !(this.clientes.containsKey(cpf))) {
			throw new IllegalArgumentException();
		}
		
		this.clientes.remove(cpf);
	}

	public String getDadosCliente(String cpf) {
		if(cpf == null || !(this.clientes.containsKey(cpf))) {
			throw new IllegalArgumentException();
		}
		
		return this.clientes.get(cpf).toString();
	}
	
	public String getDadosTodosClientes() {
		
		Iterator<Cliente> i = this.clientes.values().iterator();
		ArrayList<Cliente> clientes = new ArrayList<Cliente>();
		
		while(i.hasNext()) {
			clientes.add(i.next());
		}
		
		Collections.sort(clientes, new Comparator() {
			public int compare(Object o1, Object o2) {
				Cliente c1 = (Cliente) o1;
				Cliente c2 = (Cliente) o2;
				
				return c1.getNome().compareTo(c2.getNome());
			}
		});
		
		String saida = "";
		i = clientes.iterator();
		while(i.hasNext()) {
			saida += i.next().toString();
			if (i.hasNext()) {
				saida += " | ";
			}
		}
		
		return saida;
	}
	
	public void editaDadosCliente(String cpf, String nome, String localizacao, String email) {
		
		if(cpf == null || !(this.clientes.containsKey(cpf))) {
			throw new IllegalArgumentException();
		}
		
		this.clientes.get(cpf).setNome(nome);
		this.clientes.get(cpf).setLocalizacao(localizacao);
		this.clientes.get(cpf).setEmail(email);
		
	}
	
}
