package lab5;

public class ComboProduto implements BaseProduto {

	private String nome;
	private String descricao;
	private double preco;
	
	public ComboProduto(String nome, String descricao, Double preco) {
		this.nome = nome;
		this.preco = preco;
		this.descricao = descricao;
	}
	
	@Override
	public double getPreco() {
		return this.preco;
	}

	@Override
	public void setPreco(double preco) {
		this.preco = preco;
	}

	@Override
	public String getNome() {
		return this.nome;
	}

	@Override
	public String getDescricao() {
		return this.descricao;
	}
	
	@Override 
	public String toString() {
		return null;
	}
	@Override
	public boolean equals(Object obj) {
		return true;
	}

}
