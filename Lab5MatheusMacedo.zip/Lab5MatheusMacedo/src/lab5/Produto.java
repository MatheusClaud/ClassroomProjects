package lab5;

/**
 * Representacao de produtos oferecidos por fornecedores.
 * Cada produto possui um preco, um nome e uma descricao.
 * Cada produto e identificado unicamente pela chave formada a partir  do nome e da descricao.
 * 
 * @author Matheus Claudino
 */
public class Produto implements BaseProduto {
	
	/**
	 * preco do produto
	 */
	private double preco;
	
	/**
	 * nome do produto
	 */
	private String nome;
	
	/**
	 * descricao do produto
	 */
	private String descricao;
	
	/**
	 * Controi um produto a partir dos valores passados como parametro.
	 * Todo atributo de produto e inicializado na constucao.
	 * 
	 * @param preco
	 * @param nome
	 * @param descricao
	 */
	public Produto(Double preco, String nome, String descricao) {
		this.preco = preco;
		this.nome = nome;
		this.descricao = descricao;
	}

	/**
	 * Recupera o preco do produto.
	 * 
	 * @return preco
	 */
	public double getPreco() {
		return preco;
	}

	/**
	 * Modifica o preco do produto, a partir do valor passado por parametro.
	 * 
	 * @param preco novo preco
	 */
	public void setPreco(double preco) {
		this.preco = preco;
	}

	/**
	 * Recupera o nome do produto.
	 * 
	 * @return nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * Recupera a descricao do produto.
	 * 
	 * @return descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * Recupera a representacao textual do produto, no formato:
	 * nome - descricao - R$00.00
	 */
	@Override
	public String toString() {
		String str = String.format("%.2f", this.preco);
		str.replace(".", ",");
		return this.nome + " - " + this.descricao + " - R$" + str; 
	}
	
	/**
	 * Compara este produto ao produto passado como parametro e retorna o valor booleano referente a afirmacao: os objetos sao iguais?
	 * A condicao de igualdade � os dois terem nome e descricao iguais.
	 */
	@Override
	public boolean equals(Object obj) {
		
		if (!(this instanceof Object)) {
			return false;
		}
		
		Produto produto = (Produto) obj;
		boolean cond1 = this.nome.equals(produto.getNome());
		boolean cond2 = this.descricao.equals(produto.getDescricao());
		return cond1 && cond2;
	}
	
}
