package lab5;

public class Produto {
	
	private double preco;
	private String nome;
	private String descricao;
	
	public Produto(Double preco, String nome, String descricao) {
		this.preco = preco;
		this.nome = nome;
		this.descricao = descricao;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public String getNome() {
		return nome;
	}

	public String getDescricao() {
		return descricao;
	}

	@Override
	public String toString() {
		return this.nome + " - " + this.descricao + " - " + this.preco; 
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if (!(this instanceof Object)) {
			return false;
		}
		
		Produto produto = (Produto) obj;
		return this.nome.equals(produto.getNome());
	}
	
}
