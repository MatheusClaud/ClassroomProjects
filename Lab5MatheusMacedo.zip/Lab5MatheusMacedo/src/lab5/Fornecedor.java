package lab5;

import java.util.HashSet;

public class Fornecedor {
	
	private String nome;
	private String numeroTelefone;
	private String email;
	private HashSet<Produto> listaProdutos;
	
	public Fornecedor(String nome, String numeroTelefone, String email) {
		
		this.nome = nome;
		this.numeroTelefone = numeroTelefone;
		this.email = email;
		this.listaProdutos = new HashSet<Produto>();
		
	}

	public String getNome() {
		return nome;
	}

	public String getNumeroTelefone() {
		return numeroTelefone;
	}

	public void setNumeroTelefone(String numeroTelefone) {
		this.numeroTelefone = numeroTelefone;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return this.nome + " - " + this.email + " - " + this.numeroTelefone; 
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if (!(this instanceof Object)) {
			return false;
		}
		
		Fornecedor fornecedor = (Fornecedor) obj;
		return this.nome.equals(fornecedor.getNome());
	}
	
	
	
}
