package lab5;

import java.util.Iterator;

public class Fornecedor {
	
	private String nome;
	private String numeroTelefone;
	private String email;
	private EstruturaProduto listaProdutos;
	
	public Fornecedor(String nome, String numeroTelefone, String email) {
		
		this.nome = nome;
		this.numeroTelefone = numeroTelefone;
		this.email = email;
		this.listaProdutos = new EstruturaProduto();
		
	}

	public String getNome() {
		return nome;
	}

	public String getNumeroTelefone() {
		return numeroTelefone;
	}

	public void setNumeroTelefone(String numeroTelefone) {
		this.numeroTelefone = numeroTelefone;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void adicionaProduto(double preco, String nome, String descricao) {
		this.listaProdutos.cadastroProduto(preco, nome, descricao);
	}
	
	public String getStringProduto(String nome, String descricao) {
		return this.nome + " - " + this.listaProdutos.getStringProduto(nome, descricao);
	}
	
	public String getStringTodosProdutos() {

		Iterator lista = this.listaProdutos.getStringTodosProdutos().iterator();
		String saida = "";
		
		while (lista.hasNext()) {
			saida += this.nome + " - " + lista.next();
			if(lista.hasNext()) {
				saida += " | ";
			}
		}
		
		return saida;		
	}
	
	public void editaPrecoProduto(double preco, String nome, String descricao) {
		this.listaProdutos.editaPrecoProduto(preco, nome, descricao);
	}
	
	public void editaProduto(double preco, String nome, String descricao) {
		this.listaProdutos.recriarProduto(preco, nome, descricao);
	}
	
	public void removeProduto(String nome, String descricao) {
		this.listaProdutos.removerProduto(nome, descricao);
	}
	@Override
	public String toString() {
		return this.nome + " - " + this.email + " - " + this.numeroTelefone; 
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if (!(this instanceof Object)) {
			return false;
		}
		
		Fornecedor fornecedor = (Fornecedor) obj;
		return this.nome.equals(fornecedor.getNome());
	}
	
	
}
