package lab5;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class EstruturaProduto {
	
	private HashMap<ChaveProduto, Produto> listaProdutos;
	
	public EstruturaProduto() {
		this.listaProdutos = new HashMap<ChaveProduto, Produto>();
	}
	
	public void cadastroProduto(double preco, String nome, String descricao) {
		
		if (nome == null || descricao == null) {
			throw new IllegalArgumentException();
		}
		
		Produto produto = new Produto(preco, nome, descricao);
		ChaveProduto chaveProduto = new ChaveProduto(nome, descricao);
		
		this.listaProdutos.put(chaveProduto, produto);

	}
	
	public String getStringProduto(String nome, String descricao) {
		
		if (nome == null || descricao == null) {
			throw new IllegalArgumentException();
		}
		
		ChaveProduto chaveProduto = new ChaveProduto(nome, descricao);
		
		if (!this.listaProdutos.containsKey(chaveProduto)) {
			throw new IllegalArgumentException();
		}
		
		return this.listaProdutos.get(chaveProduto).toString();
	}
	
	public ArrayList getStringTodosProdutos() {
		
		Iterator <Produto> i = this.listaProdutos.values().iterator();
		ArrayList <String> listaDescricao = new ArrayList<String>();
		
		while(i.hasNext()) {
			listaDescricao.add(i.next().toString());
		}
		
		return listaDescricao;
	}
	
	public void removerProduto(String nome, String descricao) {
		
		if (nome == null || descricao == null) {
			throw new IllegalArgumentException();
		}
		
		ChaveProduto chaveProduto = new ChaveProduto(nome, descricao);
		
		if (!this.listaProdutos.containsKey(chaveProduto)) {
			throw new IllegalArgumentException();
		}
		
		this.listaProdutos.remove(chaveProduto);
	
	}
	
	public void recriarProduto(double preco, String nome, String descricao) {
		
		if (nome == null || descricao == null) {
			throw new IllegalArgumentException();
		}
		
		ChaveProduto chaveProduto = new ChaveProduto(nome, descricao);
		
		if (!this.listaProdutos.containsKey(chaveProduto)) {
			throw new IllegalArgumentException();
		}
		
		this.listaProdutos.remove(chaveProduto);
		Produto produto = new Produto(preco, nome, descricao);
		this.listaProdutos.put(chaveProduto, produto);
	}
	
	public void editaPrecoProduto(double preco, String nome, String descricao) {
		
		if (nome == null || descricao == null) {
			throw new IllegalArgumentException();
		}
		
		ChaveProduto chaveProduto = new ChaveProduto(nome, descricao);
		
		if (!this.listaProdutos.containsKey(chaveProduto)) {
			throw new IllegalArgumentException();
		}
		
		this.listaProdutos.get(chaveProduto).setPreco(preco);
	}
}
