package lab5;

public interface BaseProduto {

	public double getPreco();

	public void setPreco(double preco);
	
	public String getNome();
	
	public String getDescricao();

}
