package testesUnidade;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Test;

import lab5.Cliente;

public class ClienteTest {
	
	@Test
	public void testCriacaoCliente() {
		
		Cliente c1 = new Cliente("cpf", "nome", "localizacao", "email");
		assertEquals("cpf", c1.getCpf());
		assertEquals("nome", c1.getNome());
		assertEquals("localizacao", c1.getLocalizacao());
		assertEquals("email", c1.getEmail());
	}
	
	@Test
	public void testEquals() {

		Cliente c1 = new Cliente("cpf", "nome", "localizacao", "email");
		Cliente c2 = new Cliente("cpf", "nome1", "localizacao1", "email1");
		Cliente c3 = new Cliente("cpf1", "nome", "localizacao", "email");

		
		assertEquals(c1, c2);
		assertNotEquals(c1, c3);
		assertNotEquals(c2, c3);

	}
	
	@Test
	public void testToString() {
		
		Cliente c1 = new Cliente("cpf", "nome", "localizacao", "email");
		String str = "nome - localizacao - email";
		
		assertEquals(str, c1.toString());
		
	}
	
	

}
