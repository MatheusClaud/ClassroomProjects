package testesUnidade;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import lab5.Cliente;
import lab5.Produto;

public class ProdutoTest {

	
	@Test
	public void testCriacaoProduto() {
		
		Produto p1 = new Produto(111.0, "nome", "descricao");
		
		assertTrue(111.0 == p1.getPreco());
		assertEquals("nome", p1.getNome());
		assertEquals("descricao", p1.getDescricao());
		
	}
	
	@Test
	public void testEquals() {
		
		Produto p1 = new Produto(111.0, "nome", "descricao");
		Produto p2 = new Produto(111.5, "nome", "descricao");
		Produto p3 = new Produto(111.0, "nome", "descricao1");
		Produto p4 = new Produto(111.0, "nome1", "descricao");
		Produto p5 = new Produto(111.0, "nome1", "descricao1");

		assertEquals(p1, p2);
		assertNotEquals(p1, p3);
		assertNotEquals(p1, p4);
		assertNotEquals(p1, p5);
		
	}
	
	@Test
	public void testToString() {
		
		
	}
	
}
