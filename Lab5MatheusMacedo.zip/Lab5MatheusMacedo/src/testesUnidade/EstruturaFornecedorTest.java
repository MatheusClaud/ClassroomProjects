package testesUnidade;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;

import java.util.HashMap;

import org.junit.Test;

import lab5.EstruturaFornecedor;
import lab5.Fornecedor;

public class EstruturaFornecedorTest {

	
	@Test
	public void testCadastroFornecedor() {
		
		EstruturaFornecedor ef = new EstruturaFornecedor();
		ef.cadastroFornecedor("nome", "numeroTelefone", "email");
		
		HashMap map = ef.getFornecedores();
		Fornecedor f = (Fornecedor) map.get("nome");
		
		assertEquals(f.getNome(), "nome");
		assertEquals(f.getEmail(), "email");
		assertEquals(f.getNumeroTelefone(), "numeroTelefone");
		
		try {
			ef.cadastroFornecedor("nome", "numeroTelefone", "email");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ef.cadastroFornecedor(null, "numeroTelefone", "email");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ef.cadastroFornecedor("nome", null, null);
			fail();
		}catch(IllegalArgumentException e) {}
	}
	
	@Test
	public void testGetDadosFornecedor() {
		
		EstruturaFornecedor ef = new EstruturaFornecedor();
		ef.cadastroFornecedor("nome", "numeroTelefone", "email");
		
		assertEquals(ef.getDadosFornecedor("nome"), "nome - email - numeroTelefone");
		
		try {
			ef.getDadosFornecedor("nome1");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ef.getDadosFornecedor(null);
			fail();
		}catch(IllegalArgumentException e) {}
	}
	
	@Test
	public void testRemoveFornecedor() {
		
		EstruturaFornecedor ef = new EstruturaFornecedor();
		ef.cadastroFornecedor("nome", "numeroTelefone", "email");
		
		ef.removeFornecedor("nome");
		
		HashMap map = ef.getFornecedores();
		assertFalse(map.containsKey("nome"));
		
		try {
			ef.removeFornecedor("nome1");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ef.removeFornecedor(null);
			fail();
		}catch(IllegalArgumentException e) {}
	}
	
	@Test
	public void testGetDadosTodosFornecedores() {
		
		EstruturaFornecedor ef = new EstruturaFornecedor();

		assertEquals(ef.getDadosTodosFornecedores(), "");

		ef.cadastroFornecedor("enome", "numeroTelefone", "email");
		ef.cadastroFornecedor("anome", "numeroTelefone", "email");
		ef.cadastroFornecedor("cnome", "numeroTelefone", "email");

		assertEquals(ef.getDadosTodosFornecedores(), "anome - email - numeroTelefone | cnome - email - numeroTelefone | enome - email - numeroTelefone");	
	}
	
	@Test
	public void testEditaDadosFornecedor() {
		
		EstruturaFornecedor ef = new EstruturaFornecedor();
		ef.cadastroFornecedor("nome", "numeroTelefone", "email");
		
		ef.editaDadosFornecedor("nome", "telefone", "telefone1");

		ef.editaDadosFornecedor("nome", "email", "email1");

		HashMap map = ef.getFornecedores();
		Fornecedor f = (Fornecedor) map.get("nome");
		
		assertEquals(f.getNome(), "nome");
		assertEquals(f.getEmail(), "email1");
		assertEquals(f.getNumeroTelefone(), "telefone1");
		
		try {
			ef.editaDadosFornecedor("nome", "nome", "nome1");
			fail();
		}catch(IllegalArgumentException e){}
			
		try {
			ef.editaDadosFornecedor("nome", "el", "el1");
			fail();
		}catch(IllegalArgumentException e){}


		
	}
	
	@Test
	public void testGetStringTodosProdutosTodosFornecedores() {
		
		EstruturaFornecedor ef = new EstruturaFornecedor();
		ef.cadastroFornecedor("nomeFornecedor", "numeroTelefone", "email");
		ef.cadastroFornecedor("anomeFornecedor", "numeroTelefone1", "email1");
		ef.cadastroFornecedor("cnomeFornecedor", "numeroTelefone1", "email1");
		
		ef.cadastroProdutoFornecedor("nomeFornecedor", 110.0, "nome", "descricao");
		ef.cadastroProdutoFornecedor("anomeFornecedor", 110.0, "nome", "descricao");
		ef.cadastroProdutoFornecedor("cnomeFornecedor", 110.0, "nome", "descricao");
		
		assertEquals(ef.getStringTodosProdutosTodosFornecedores() , "anomeFornecedor - nome - descricao - R$110,00 | cnomeFornecedor - nome - descricao - R$110,00 | nomeFornecedor - nome - descricao - R$110,00");
		
	}
	
}
