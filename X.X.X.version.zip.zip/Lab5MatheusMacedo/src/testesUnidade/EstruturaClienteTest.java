package testesUnidade;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;

import org.junit.Test;

import lab5.Cliente;
import lab5.ControlerCliente;

public class EstruturaClienteTest {

	@Test
	public void testCadastroCliente() {
		
		ControlerCliente ec = new ControlerCliente();
		ec.cadastroCliente("00000000000", "nome", "localizacao", "email");
		HashMap map = ec.getClientes();
		
		assertTrue(map.containsKey("00000000000"));
		Cliente c = (Cliente) map.get("00000000000");
		assertEquals(c.getNome(), "nome");
		assertEquals(c.getEmail(), "email");
		assertEquals(c.getLocalizacao(), "localizacao");
		assertEquals(c.getCpf(), "00000000000");
		
		try {
			ec.cadastroCliente("00000000000", "nome", "localizacao", "email");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ec.cadastroCliente("00000000000", null, null, null);
			fail();
		}catch(IllegalArgumentException e) {}
		
	}
	
	@Test
	public void testRemoverCliente() {
		
		ControlerCliente ec = new ControlerCliente();
		ec.cadastroCliente("00000000000", "nome", "localizacao", "email");
		ec.removerCliente("00000000000");
		
		HashMap map = ec.getClientes();
		assertFalse(map.containsKey("00000000000"));
		
		try {
			ec.removerCliente("00000000001");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ec.removerCliente(null);
			fail();
		}catch(IllegalArgumentException e) {}
		
	}
	
	@Test
	public void testGetDadosCliente() {
		
		ControlerCliente ec = new ControlerCliente();
		ec.cadastroCliente("00000000000", "nome", "localizacao", "email");
		
		assertEquals(ec.getDadosCliente("00000000000"), "nome - localizacao - email");
		
		try {
			ec.getDadosCliente("sss");
		}catch(IllegalArgumentException e) {}
		
		try {
			ec.getDadosCliente(null);
		}catch(IllegalArgumentException e) {}
		
	}
	
	@Test
	public void testGetDadosTodosClientes() {
		
		ControlerCliente ec = new ControlerCliente();
		
		assertEquals(ec.getDadosTodosClientes(), "");
		
		ec.cadastroCliente("00000000000", "nome", "localizacao", "email");
		ec.cadastroCliente("00000000001", "bnome", "localizacao", "email");
		ec.cadastroCliente("00000000002", "anome", "localizacao", "email");

		assertEquals(ec.getDadosTodosClientes(), "anome - localizacao - email | bnome - localizacao - email | nome - localizacao - email");
			
	}
	
	@Test
	public void testEditaDadosCliente() {
		
		ControlerCliente ec = new ControlerCliente();

		ec.cadastroCliente("00000000000", "nome", "localizacao", "email");

		ec.editaDadosCliente("00000000000", "nome", "nome1");
		ec.editaDadosCliente("00000000000", "email", "email1");
		ec.editaDadosCliente("00000000000", "localizacao", "localizacao1");


		HashMap map = ec.getClientes();

		Cliente c = (Cliente) map.get("00000000000");
		assertEquals(c.getNome(), "nome1");
		assertEquals(c.getEmail(), "email1");
		assertEquals(c.getLocalizacao(), "localizacao1");
		assertEquals(c.getCpf(), "00000000000");
		
		try {
			ec.editaDadosCliente("00000000000", "nome", null);
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ec.editaDadosCliente(null, "nome", "nome1");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ec.editaDadosCliente("00000000000", "hhhh", "hhhh1");
			fail();
		}catch(IllegalArgumentException e) {}
	}
	
}