package testesUnidade;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.HashMap;

import org.junit.Test;

import lab5.ChaveProduto;
import lab5.ControlerProduto;
import lab5.Produto;

public class EstruturaProdutoTest {

	@Test
	public void testCadastroProduto() {
		
		ControlerProduto ep = new ControlerProduto();
		ep.cadastroProduto(110.0, "nome", "descricao");
		
		HashMap map = ep.getListaProdutos();
		ChaveProduto c = new ChaveProduto("nome", "descricao");

		assertTrue(map.containsKey(c));
		
		Produto p = (Produto) map.get(c);

		assertEquals(p.getNome(), "nome");
		assertEquals(p.getDescricao(), "descricao");
		assertTrue(p.getPreco() == 110.0);
		
		try {
			ep.cadastroProduto(110.0, "nome", "descricao");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ep.cadastroProduto(-2, "nome", "descricao");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ep.cadastroProduto(110.0, null, null);
			fail();
		}catch(IllegalArgumentException e) {}
	}
	
	@Test
	public void testGetStringProduto() {
		
		ControlerProduto ep = new ControlerProduto();
		ep.cadastroProduto(110.0, "nome", "descricao");
		
		assertEquals(ep.getStringProduto("nome", "descricao"),"nome - descricao - R$110,00");
		
		try {
			ep.getStringProduto("nome1", "descricao");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ep.getStringProduto("nome", "descricao1");
			fail();
		}catch(IllegalArgumentException e) {}
	}
	
	
	@Test
	public void testRemoveProduto() {
		
		ControlerProduto ep = new ControlerProduto();
		ep.cadastroProduto(110.0, "nome", "descricao");

		ep.removeProduto("nome", "descricao");	
		
		HashMap map = ep.getListaProdutos();
		ChaveProduto c = new ChaveProduto("nome", "descricao");

		assertFalse(map.containsKey(c));

		
		try {
			ep.removeProduto("nome", "descricao");	
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ep.getStringProduto(null, "descricao1");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ep.getStringProduto("nome", null);
			fail();
		}catch(IllegalArgumentException e) {}
	}
	
	@Test
	public void testEditaPrecoProduto() {
		
		ControlerProduto ep = new ControlerProduto();
		ep.cadastroProduto(110.0, "nome", "descricao");
		
		ep.editaPrecoProduto(111.0,"nome" , "descricao");
		
		ChaveProduto c = new ChaveProduto("nome", "descricao");

		HashMap map = ep.getListaProdutos();
		Produto p = (Produto) map.get(c);
		
		assertTrue(p.getPreco() == 111.0);

		try {
			ep.editaPrecoProduto(111.0,"nome1" , "descricao1");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ep.editaPrecoProduto(111.0,null , "descricao");
			fail();
		}catch(IllegalArgumentException e) {}
		
		try {
			ep.editaPrecoProduto(-111.0,"nome" , "descricao");
			fail();
		}catch(IllegalArgumentException e) {}
	}
	
	
}
