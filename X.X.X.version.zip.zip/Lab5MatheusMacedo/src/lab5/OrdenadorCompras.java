package lab5;

import java.awt.List;
import java.util.ArrayList;

public interface OrdenadorCompras {

	public String getStringListaOrdenada(ArrayList listaCompras);
	
}
