package lab5;

/**
 * Representacao da chave identificacao dos produtos.
 * A funcao basica desta classe e acessar as informacoes de estruturas de produto.
 * Cada chave possui nome e descricao, obrigatoriamente.
 * 
 * @author Matheus Claudino
 */
public class ChaveProduto {
	
	/**
	 * nome do produto que a chave representa
	 */
	private String nome;
	
	/**
	 * descricao do produto que a chave representa
	 */
	private String descricao;
	
	/**
	 * Constroi a chave a partir dos valores passados como parametro.
	 * Todos os atributos sao inicializados na construcao.
	 * 
	 * @param nome
	 * @param descricao
	 */
	public ChaveProduto(String nome, String descricao) {
		this.nome = nome;
		this.descricao = descricao;
	}
	
	/**
	 * Recupera o nome do produto, o qual a chave representa.
	 * 
	 * @return nome do produto
	 */
	public String getNome() {
		return this.nome;
	}
	
	/**
	 * Recupera a descricao do produto, o qual a chave representa.
	 * 
	 * @return descricao do produto
	 */
	public String getDescricao() {
		return this.descricao;
	}

	/**
	 * Compara esta chave com outra, retornando o valor booleano referente a afirma�ao: as duas sao iguais?
	 * A condicao de igualdade e possuir nome e descricao iguais.
	 */
	@Override
	public boolean equals(Object o) {
		if (!(this instanceof Object)) {
			throw new IllegalArgumentException();
		}
		
		ChaveProduto chave = (ChaveProduto) o;
		
		boolean cond1 = this.nome.equals(chave.getNome());
		boolean cond2 = this.descricao.equals(chave.getDescricao());
	
		return cond1 && cond2;
	}
	
	/**
	 * Retorna o valor hash das caracteristicasque identificam os produtos
	 */
	@Override
	public int hashCode() {
		return (this.nome + this.descricao).hashCode();
	}

}
