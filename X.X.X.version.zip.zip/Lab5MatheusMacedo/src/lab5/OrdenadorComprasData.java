package lab5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class OrdenadorComprasData implements OrdenadorCompras {

	@Override
	public String getStringListaOrdenada(ArrayList listaClientes) {

		ArrayList listaOrdenada = listaClientes;
		
		ArrayList listaUniforme = new ArrayList();
		
		for(int i = 0; i < listaOrdenada.size(); i++) {
			ArrayList listaContas = (ArrayList) listaOrdenada.get(i);
			
			for (int j = 0; j < listaContas.size(); j++) {
				Conta conta = (Conta) listaContas.get(j);
				ArrayList listaCompras = conta.getListaComprasConta();
				
				for (int g = 0; g < listaCompras.size(); g++ ) {
					Compra compra = (Compra) listaCompras.get(g);
					listaUniforme.add(compra);
				}
			}
	
		}
		
		Collections.sort(listaUniforme, new Comparator(){
			public int compare(Object o1, Object o2) {
				Compra a1 = (Compra) o1;
				Compra a2 = (Compra) o2;
				
				int cond1 = a1.getData().substring(6, 10).compareTo(a2.getData().substring(6, 10));
				int cond2 = a1.getData().substring(3, 5).compareTo(a2.getData().substring(3, 5));
				int cond3 = a1.getData().substring(0, 2).compareTo(a2.getData().substring(0, 2));

				if(cond1 != 0) {
					return cond1;
				}	
				if (cond2 != 0) {
					return cond2;
				}

				if (cond3 != 0 ) {
					return cond3;
				}
					
				return (a1.getCliente() + a1.getFornecedor()+ a1.getDescricaoProduto()).compareTo(a2.getCliente() + a2.getFornecedor()+ a2.getDescricaoProduto());
			}
		});
		
		String saida = "";
		
		for(int i = 0; i < listaUniforme.size(); i++) {
					
			Compra compra = (Compra) listaUniforme.get(i);
					
			saida += compra.getData() + ", " + compra.getCliente() + ", " + compra.getFornecedor() + ", "+ compra.getDescricaoProduto();
					
			saida += " | ";
			
				
		}
	
		
		
		return saida.substring(0, saida.length()-3);
	}
}
