
package lab5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Controlador da estrutura conjunto de produtos.
 * Responsavel por regular e limitar a atribuicao e o acesso a dados de produtos.
 * O unico atributo que possui e o mapa de produtos.
 * 
 * @author Matheus Claudino
 */
public class ControlerProduto {
	
	/**
	 * conjunto de produtos, representados em formato de mapa
	 */
	private HashMap<ChaveProduto, Produto> produtos;
	
	/**
	 * constroi o mapa como HashMap
	 */
	public ControlerProduto() {
		this.produtos = new HashMap<ChaveProduto, Produto>();
	}
	
	/**
	 * Retorna o mapa de produtos
	 * 
	 * @return produtos
	 */
	public HashMap getListaProdutos() {
		return this.produtos;
	}
	
	public Produto getProduto(String nome, String descricao) {
		ChaveProduto chave = new ChaveProduto(nome, descricao);
		
		if (!this.produtos.containsKey(chave)){
			return null;
		}
		
		return this.produtos.get(chave);
	}
	
	/**
	 * Metodo responsavel pela criacao de novos produtos e pela insercao deles no conjunto de produtos.
	 * Os novos produtos sao criados a partir dos valores passados como parametro.
	 * Nao e possivel repetir produtos.
	 * 
	   Lanca IllegalArgumentException caso nome ou descricao sejam nulos ou vazios.
	   Lanca IllegalArgumentException caso ja exista um mesmo produto no conjunto de Produtos.
	   Lanca IllegalArgumentException caso preco seja menor que zero.
	 * 
	 * @param preco
	 * @param nome
	 * @param descricao
	 */
	public void cadastroProduto(double preco, String nome, String descricao) {
		
		ChaveProduto chaveProduto = new ChaveProduto(nome, descricao);
		
		if (nome == null || nome.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro de produto: nome nao pode ser vazio ou nulo.");

		}
		
		if (descricao == null || descricao.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro de produto: descricao nao pode ser vazia ou nula.");
		}
		
		if (preco < 0) {
			throw new IllegalArgumentException("Erro no cadastro de produto: preco invalido.");

		}
		
		if (this.produtos.containsKey(chaveProduto)) {
			throw new IllegalArgumentException("Erro no cadastro de produto: produto ja existe.");
		}
		
		Produto produto = new Produto(preco, nome, descricao);
		
		this.produtos.put(chaveProduto, produto);

	}
	
	
	/**
	 * Metodo responsavel por retornar a representacao textual de um cliente, identificado pelo cpf.
	 * 
	 * Lanca IllegalArgumentException caso nome e descricao passados por parametro sejam nulos, vazios ou nao referenciem nenhum produto.
	 * 
	 * @param nome
	 * @param descricao
	 * @return representacao textual prosuto
	 */
	public String getStringProduto(String nome, String descricao) {
		
		if (nome == null || nome.equals("")) {
			throw new IllegalArgumentException("Erro na exibicao de produto: nome nao pode ser vazio ou nulo.");
		}
		
		if (descricao == null || descricao.equals("")) {
			throw new IllegalArgumentException("Erro na exibicao de produto: descricao nao pode ser vazia ou nula.");

		}
		
		ChaveProduto chaveProduto = new ChaveProduto(nome, descricao);
		
		if (!this.produtos.containsKey(chaveProduto)) {
			throw new IllegalArgumentException("Erro na exibicao de produto: produto nao existe.");
		}
		
		return this.produtos.get(chaveProduto).toString();
	}
	
	/**
	 * Metodo responsavel por retornar a representacao textual do todos os produtos no conjunto de produtos.
	 * Caso nao possua nenhum produto cadastrado retorna "".
	 * Caso possua mais de um produto cadastrado retorna as representacoes separadas por |.
	 * 
	 * @return representacao textual de todos os produtos
	 */
	public ArrayList getStringTodosProdutos() {
		
		Iterator<Produto> i = this.produtos.values().iterator();
		ArrayList <Produto> listaDescricao = new ArrayList<Produto>();
		
		while(i.hasNext()) {
			listaDescricao.add(i.next());
		}
		
		Collections.sort(listaDescricao, new Comparator() {
			public int compare(Object o1, Object o2) {
				Produto f1 = (Produto) o1;
				Produto f2 = (Produto) o2;
				
				return f1.getNome().compareTo(f2.getNome());
			}
		});
		
		return listaDescricao;
	}
	
	/**
	 *  Metodo responsavel por retirar um dado produto, identificado pelo nome e descricao, do conjunto de clientes.
	 * 
		Lanca IllegalArgumentException caso nome e descricao passados por parametro sejam nulos, vazios ou nao referenciem nenhum produto.
	 * 
	 * @param nome
	 * @param descricao
	 */
	public void removeProduto(String nome, String descricao) {
		
		if (nome == null || nome.equals("")) {
			throw new IllegalArgumentException("Erro na remocao de produto: nome nao pode ser vazio ou nulo.");

		}
		
		if (descricao == null || descricao.equals("")) {
			throw new IllegalArgumentException("Erro na remocao de produto: descricao nao pode ser vazia ou nula.");

		}
		
		ChaveProduto chaveProduto = new ChaveProduto(nome, descricao);
		
		if (!this.produtos.containsKey(chaveProduto)) {
			throw new IllegalArgumentException("Erro na remocao de produto: produto nao existe.");
		}
		
		this.produtos.remove(chaveProduto);
	
	}
	
	
	/**
	 * Metodo responsavel por modificar dados dos produtos, a partir do nome e da descricao do que se deseja modificar.
	 * 
		Lanca IllegalArgumentException caso nome e descricao passados por parametro sejam nulos, vazios ou nao referenciem nenhum produto.
	   Lanca IllegalArgumentException caso preco seja menor que 0.
	   
	 * @param preco
	 * @param nome
	 * @param descricao
	 */
	public void editaPrecoProduto(double preco, String nome, String descricao) {
		

		if (preco < 0) {
			throw new IllegalArgumentException("Erro na edicao de produto: preco invalido.");
		}
		
		if (descricao == null || descricao.equals("")) {
			throw new IllegalArgumentException("Erro na edicao de produto: descricao nao pode ser vazia ou nula.");
		}
		
		if (nome == null || nome.equals("")) {
			throw new IllegalArgumentException("Erro na edicao de produto: nome nao pode ser vazio ou nulo.");
		}
		
		ChaveProduto chaveProduto = new ChaveProduto(nome, descricao);
		
		if (!this.produtos.containsKey(chaveProduto)) {
			throw new IllegalArgumentException("Erro na edicao de produto: produto nao existe.");
		}
		
		this.produtos.get(chaveProduto).setPreco(preco);
	}
	
	public void cadastroComboProduto(String descricao, String nome, double fator, String produtos) {
		
		if (nome == null || nome.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro de combo: nome nao pode ser vazio ou nulo.");
		}
		
		if (descricao == null || descricao.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro de combo: descricao nao pode ser vazia ou nula.");
		}
		
		if (produtos == null || produtos.equals("")) {
			throw new IllegalArgumentException("Erro no cadastro de combo: combo deve ter produtos.");
		}
		
		if (fator >= 1 || fator <= 0) {
			throw new IllegalArgumentException("Erro no cadastro de combo: fator invalido.");
		}
		
		ChaveProduto c = new ChaveProduto(nome, descricao);
		
		if (this.produtos.containsKey(c)) {
			throw new IllegalArgumentException("Erro no cadastro de combo: combo ja existe.");
		}
		
		Double preco = 0.0;
		
		String[] chavesString = produtos.split(", ");
		ArrayList<ChaveProduto> chaves = new ArrayList<ChaveProduto>();
		
		for (int i = 0; i < chavesString.length; i++) {
			String[] str = chavesString[i].split(" - ");
			ChaveProduto chave = new ChaveProduto(str[0], str[1]);
			
			if (!this.produtos.containsKey(chave)) {
				throw new IllegalArgumentException("Erro no cadastro de combo: produto nao existe.");
			}
			
			if (this.produtos.get(chave) instanceof ComboProduto) {
				throw new IllegalArgumentException("Erro no cadastro de combo: um combo nao pode possuir combos na lista de produtos.");
			}
			
			chaves.add(chave);
		}
		
		for (int i =0; i < chaves.size(); i++) {
			preco += this.produtos.get(chaves.get(i)).getPreco();
		}
		
		preco *= (1 - fator);
		
		ComboProduto novoProduto = new ComboProduto(nome, descricao, preco, fator);
		ChaveProduto chaveNovoProduto = new ChaveProduto(nome, descricao);
		this.produtos.put(chaveNovoProduto, novoProduto);
		
	}
	
	public void editaFatorDesconto(String descricao, String nome, double novoFator) {
		
		if (nome == null || nome.equals("")) {
			throw new IllegalArgumentException("Erro na edicao de combo: nome nao pode ser vazio ou nulo.");
		}
		
		if (descricao == null || descricao.equals("")) {
			throw new IllegalArgumentException("Erro na edicao de combo: descricao nao pode ser vazia ou nula.");
		}
		
		if (novoFator >= 1 || novoFator <= 0) {
			throw new IllegalArgumentException("Erro na edicao de combo: fator invalido.");
		}
		
		ChaveProduto c = new ChaveProduto(nome, descricao);
		
		if (!this.produtos.containsKey(c)) {
			throw new IllegalArgumentException("Erro na edicao de combo: produto nao existe.");
		}
		
		ChaveProduto chave = new ChaveProduto(nome, descricao);
		ComboProduto p = (ComboProduto) this.produtos.get(chave);
		p.setFatorDescricao(novoFator);
	}
}
