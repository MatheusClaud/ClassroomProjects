package lab5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

public class OrdenadorComprasFornecedor implements OrdenadorCompras {

	
	@Override
	public String getStringListaOrdenada(ArrayList listaClientes) {

		ArrayList listaOrdenada = listaClientes;
		
		ArrayList listaUniforme = new ArrayList();
		
		for(int i = 0; i < listaOrdenada.size(); i++) {
			ArrayList listaContas = (ArrayList) listaOrdenada.get(i);
			
			for (int j = 0; j < listaContas.size(); j++) {
				Conta conta = (Conta) listaContas.get(j);
				listaUniforme.add(conta);
			}
	
		}
		
		Collections.sort(listaUniforme, new Comparator(){
			public int compare(Object o1, Object o2) {
				Conta a1 = (Conta) o1;
				Conta a2 = (Conta) o2;
				
				int cond = a1.getFornecedor().compareTo(a2.getFornecedor());
				if(cond != 0) {
					return cond;
				}else {
					return (a1.getCliente() + ", "+ a1.toString()).compareTo(a2.getCliente() + ", "+ a2.toString());
				}
			}
		});
		
		String saida = "";
		
		for(int i = 0; i < listaUniforme.size(); i++) {
					
			Conta conta = (Conta) listaUniforme.get(i);
			ArrayList listaCompras = conta.getListaComprasConta();
			
			Collections.sort(listaCompras, new Comparator() {
				public int compare(Object o1, Object o2) {
					Compra a1 = (Compra) o1;
					Compra a2 = (Compra) o2;
					
					return (a1.toString()).compareTo(a2.toString());
				}
			});
					
			for (int g = 0; g < listaCompras.size(); g++) {
				Compra compra = (Compra) listaCompras.get(g);
					
				saida += conta.getFornecedor() + ", " + conta.getCliente() + ", " + compra.toString();
					
				saida += " | ";
			}
				
		}
	
		
		
		return saida.substring(0, saida.length()-3);
	}
}
