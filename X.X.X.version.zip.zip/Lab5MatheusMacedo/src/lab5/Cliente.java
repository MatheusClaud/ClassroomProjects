package lab5;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * Representacao de um cliente, todo cliente e identificado unicamente pelo seu cpf.
 * Todo cliente deve possuir nome, localizacao e email.
 * @author Matheus Claudino
 */
public class Cliente {
	
	/**
	 * cpf do cliente.
	 */
	private String cpf;
	
	/**
	 * nome do cliete.
	 */
	private String nome;
	
	/**
	 * localizacao em que o cliente atua.
	 */
	private String localizacao;
	
	/**
	 * email do cliente.
	 */
	private String email;
	
	/**
	 * registro de contas e despesas do cliente
	 */
	private ControlerConta controlerConta;


	/**
	 * Contr�i um cliente a partir dos valores passados por parametro. inicializando todos os atributos do cliente.
	 * 
	 * @param cpf 
	 * @param nome
	 * @param localizacao
	 * @param email
	 */
	public Cliente(String cpf, String nome, String localizacao, String email) {
		this.cpf = cpf;
		this.nome = nome;
		this.localizacao = localizacao;
		this.email = email;
		this.controlerConta = new ControlerConta();
	}

	/**
	 * Recupera o cpf.
	 * @return cpf do cliente
	 */
	public String getCpf() {
		return cpf;
	}

	/**
	 * Recupera o nome.
	 * @return nome do cliente
	 */
	public String getNome() {
		return nome;
	}
	
	/**
	 * Modifica o nome do cliente.
	 * 
	 * @param nome novo nome
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * Recupera a localizacao do cliente.
	 * 
	 * @return localizacao
	 */
	public String getLocalizacao() {
		return localizacao;
	}

	/**
	 * Recupera o email do cliente.
	 * 
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	
	/**
	 * Modifica a localizacao do cliente.
	 * 
	 * @param localizacao nova localizacao
	 */
	public void setLocalizacao(String localizacao) {
		this.localizacao = localizacao;
	}
	
	/**
	 * Modifica o email do cliente.
	 * 
	 * @param email novo email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	
	/**
	 * Retorna a representacao textual do cliente.
	 * O formato retornado obedesce o formato:
	 *  nome - localizacao - email
	 */
	
	public void adicionaCompra(String fornecedor, String data, String nomeProduto, String descricaoProduto, double preco) {
		
		this.controlerConta.cadastraCompra(this.nome, fornecedor, data, nomeProduto, descricaoProduto, preco);
	
	}
	
	/**
	 * Retorna o valor monetario da soma total das dividas do cliente com o fornecedor identificado por parametro.
	 * 
	 * @param nomeFornecedor identificacao do fornecedor
	 * @return divida do cliene com o fornecedor
	 */
	public double getDebito(String nomeFornecedor) {
		return this.controlerConta.getDebito(nomeFornecedor);
	}
	/**
	 * Retorna a representacao em string das dividas do vliente com um fornecedor especificado
	 * @param nomeFornecedor identificacao do fornecedor
	 * @return represetacao das dividas com um fornecedor
	 */
	public String exibeContas(String nomeFornecedor) {
		return "Cliente: " + this.nome + " | " + this.controlerConta.exibeContas(nomeFornecedor);
	}
	/**
	 * Retorna a representacao em string das dividas totais do cliente com todos os fornecedores
	 * @return representacao de todas as dividas do cliente
	 */
	public String exibeContasClientes() {
		return "Cliente: " + this.nome + " | " + this.controlerConta.exibeContasClientes();
	}
	
	/**
	 * Realiza pagamento de uma divida com algum fornecedor
	 * @param nomeFornecedor identificador do forneceodor
	 */
	public void realizaPagamento(String nomeFornecedor) {
		this.controlerConta.realizaPagamento(nomeFornecedor);
	}
	
	/**
	 * Retorna uma lista das compras realizadas pelo cliente com todos os fornecedores
	 * @return ArrayList de compras
	 */
	public ArrayList getListaContas() {
		return this.controlerConta.getListaContas();
	}
	
	/**
	 * Retorna a representacao em string do cliente
	 */
	@Override
	public String toString() {
		return this.nome + " - " + this.localizacao + " - " + this.email; 
	}
	
	/**
	 * Compara o presente cliente com outro e retorna o valor booleano correspondente a afirmacao: os dois sao iguais?.
	 * A condicao de igualdade e possuir o mesmo cpf.
	 */
	@Override
	public boolean equals(Object obj) {
		
		if (!(this instanceof Object)) {
			return false;
		}
		
		Cliente cliente = (Cliente) obj;
		return this.cpf.equals(cliente.getCpf());
	}
	
	
}
