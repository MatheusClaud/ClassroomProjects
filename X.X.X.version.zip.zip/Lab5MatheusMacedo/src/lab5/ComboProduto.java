package lab5;

/**
 * Representacao de um combo de produtos, no sistema o combo de produtos e visto como sendo uma exrencao da representacao de produto.
 * Todas as caracteristicas chave de produto tambem sao caracteristicas de comboproduto.
 * Todo combo produto possui um fato de desconto que  modifica o preco original do combo.
 * 
 * @author Matheus Claudino
 *
 */
public class ComboProduto extends Produto {
	
	/**
	 * fator de desconto do combp de produtos
	 */
	private double fatorDesconto;
	
	/**
	 * controi um combo de produtos a partir dos valores passados como parametro
	 * 
	 * @param nome nome do combo
	 * @param descricao descricao do combo
	 * @param preco preco do combo com o fator ja aplicado
	 * @param fator fator de desconto aplicado
	 */
	public ComboProduto(String nome, String descricao, Double preco, Double fator) {
		super(preco, nome, descricao);
		this.fatorDesconto = fator;
	}
	
	/**
	 * modifica o fator de desconto do combo.
	 * ao modificar o fator desconto o preco tambem e mudado
	 * 
	 * @param novoFator novo fator desconto
	 */
	public void setFatorDescricao(double novoFator) {
		super.setPreco((super.getPreco() / ((1-this.fatorDesconto))) * (1 - novoFator));
		this.fatorDesconto = novoFator;
	}
	
	/**
	 * retorna o fator desconto do combo
	 * 
	 * @return fator desconto
	 */
	public double getFatorDesconto() {
		return this.fatorDesconto;
	}
	
	

}
