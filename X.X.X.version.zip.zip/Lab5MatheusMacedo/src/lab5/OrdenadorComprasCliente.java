package lab5;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

public class OrdenadorComprasCliente implements OrdenadorCompras {

	@Override
	public String getStringListaOrdenada(ArrayList listaClientes) {
		
		ArrayList listaNomes = new ArrayList();
		ArrayList listaOrdenada = listaClientes;
		HashMap<String, String> mapa = new HashMap<String, String>();

		for(int i = 0; i < listaOrdenada.size(); i++) {
			ArrayList listaContas = (ArrayList) listaOrdenada.get(i);
			
			for (int j = 0; j < listaContas.size(); j++) {
				Conta conta = (Conta) listaContas.get(j);
				listaNomes.add(conta.getCliente());
				mapa.put(conta.getCliente(), Integer.toString(i));
				break;		
			}
	
		}
		
		Collections.sort(listaNomes);
		
		String saida = "";
		
		for(int i = 0; i < listaNomes.size(); i++) {
			ArrayList listaContas = (ArrayList) listaOrdenada.get(Integer.parseInt(mapa.get(listaNomes.get(i))));
			
			Collections.sort(listaContas, new Comparator() {
				public int compare(Object o1, Object o2) {
					Conta a1 = (Conta) o1;
					Conta a2 = (Conta) o2;
					
					return a1.getFornecedor().compareTo(a2.getFornecedor());
				}
			});
			
			
			for (int j = 0; j < listaContas.size(); j++) {
				Conta conta = (Conta) listaContas.get(j);
				ArrayList listaCompras = conta.getListaComprasConta();
				
				Collections.sort(listaCompras, new Comparator() {
					public int compare(Object o1, Object o2) {
						Compra a1 = (Compra) o1;
						Compra a2 = (Compra) o2;
						
						return (a1.toString()).compareTo(a2.toString());
					}
				});	
				
				for (int g = 0; g < listaCompras.size(); g++) {
					Compra compra = (Compra) listaCompras.get(g);
					
					saida += conta.getCliente() + ", "+conta.getFornecedor() + ", " + compra.toString();
					
					saida += " | ";
				}
				
			}
	
			
		}
		
		
		return saida.substring(0, saida.length()-3);
	}
	
	
	
	

}
