package lab5;

public class Compra {
	
	private String data;
	private String nomeProduto;
	private String descricaoProduto;
	private String cliente;
	private String fornecedor;
	private double preco;
	
	public Compra(String data, String nomeProduto, String descricaoProduto, double preco, String cliente, String fornecedor) {
		this.data = data;
		this.nomeProduto =nomeProduto;
		this.descricaoProduto = descricaoProduto;
		this.preco = preco;
		this.cliente = cliente;
		this.fornecedor = fornecedor;
	}
	
	public String getData() {
		return this.data;
	}

	public String getNomeProduto() {
		return this.nomeProduto;
	}
	
	public String getCliente() {
		return this.cliente;
	}
	
	public String getFornecedor() {
		return this.fornecedor;
	}

	public String getDescricaoProduto() {
		return this.descricaoProduto;
	}

	public double getPreco() {
		return this.preco;
	}
	
	@Override
	public String toString() {
		return this.descricaoProduto+ ", "+this.data;
	}

	
}
