package lab5;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import java.util.Iterator;

public class Conta {
	
	private Set<Compra> contasFornecedores;
	private String fornecedor;
	private String cliente;
	
	public Conta(String fornecedor, String cliente) {
		this.contasFornecedores = new HashSet<Compra>();
		this.fornecedor = fornecedor;
		this.cliente = cliente;
	}
	
	public void cadastraCompra(String data, String nomeProduto, String descricaoProduto, double preco) {
		Compra compra = new Compra(data, nomeProduto, descricaoProduto, preco, cliente, fornecedor);
		this.contasFornecedores.add(compra);
		
	}
	
	public String getFornecedor() {
		return this.fornecedor;
	}
	
	public String getCliente() {
		return this.cliente;
	}
	
	public Double getDebito() {
		Iterator <Compra> i = this.contasFornecedores.iterator();
		
		Double debito = 0.0;
		
		while(i.hasNext()) {
			debito += i.next().getPreco();
		}
		
		return debito;
	}
	
	public String getStringCompra() {
		Iterator <Compra> i = this.contasFornecedores.iterator();
		
		String saida = "";
		
		while(i.hasNext()) {
			Compra p = i.next();
			saida += p.getNomeProduto() + " - " + p.getData().replace("/", "-");
			
			if (i.hasNext()) {
				saida += " | ";
			}
		}
		
		return saida;
	}
	
	public ArrayList getListaComprasConta() {
		Iterator <Compra> i = this.contasFornecedores.iterator();
		
		ArrayList saida = new ArrayList();
		
		while(i.hasNext()) {
			saida.add(i.next());
		}
		
		return saida;
	}
	

}
