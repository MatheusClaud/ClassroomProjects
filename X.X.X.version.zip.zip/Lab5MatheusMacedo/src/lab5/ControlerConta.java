
package lab5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class ControlerConta {
	
	private Map contas;
	
	public ControlerConta() {
		contas = new HashMap<String, Conta>();
	}
	
	public void cadastraCompra(String nomeCliente, String nomeFornecedor, String data, String nomeProduto, String descricaoProduto, double preco) {
		
		if (data == null || data.equals("")) {
			throw new IllegalArgumentException("Erro ao cadastrar compra: data nao pode ser vazia ou nula.");
		}
		
		String[] partesData = data.split("/");
		
		if (partesData[0].length() != 2 || partesData[1].length() != 2 || partesData[2].length() != 4) {
			throw new IllegalArgumentException("Erro ao cadastrar compra: data invalida.");
		}
		
		if (!this.contas.containsKey(nomeFornecedor)) {
			Conta conta = new Conta(nomeFornecedor, nomeCliente);
			this.contas.put(nomeFornecedor, conta);
		}
		
		Conta c = (Conta) this.contas.get(nomeFornecedor);
		c.cadastraCompra(data, nomeProduto, descricaoProduto, preco);
		
	}
	
	public double getDebito(String nomeFornecedor) {
		
		if (!this.contas.containsKey(nomeFornecedor)) {
			throw new IllegalArgumentException("Erro ao recuperar debito: cliente nao tem debito com fornecedor.");
		}
		
		Conta conta = (Conta) this.contas.get(nomeFornecedor);
		
		return conta.getDebito();
	}
	
	public String exibeContas(String nomeFornecedor) {
		
		if (!this.contas.containsKey(nomeFornecedor)) {
			throw new IllegalArgumentException("Erro ao exibir conta do cliente: cliente nao tem nenhuma conta com o fornecedor.");
		}
		
		Conta conta = (Conta) this.contas.get(nomeFornecedor);
		
		return  nomeFornecedor+ " | "+conta.getStringCompra();
	}
	
	public String exibeContasClientes() {
		
		Iterator<String> it = this.contas.keySet().iterator();
		ArrayList<String> lista = new ArrayList<String>();
		
		while (it.hasNext()) {
			lista.add(it.next());
		}
		
		if (lista.size() == 0) {
			throw new IllegalArgumentException("Erro ao exibir contas do cliente: cliente nao tem nenhuma conta.");
		}
		
		Collections.sort(lista);
		
		String saida = "";
		
		for (int i = 0; i < lista.size(); i++) {
			saida += exibeContas(lista.get(i));
			if (i+1 < lista.size()) {
				saida += " | ";
			}
		}
		
		return saida;
	}
	
	public void realizaPagamento(String nomeFornecedor) {
		
		if (!this.contas.containsKey(nomeFornecedor)) {
			throw new IllegalArgumentException("Erro no pagamento de conta: nao ha debito do cliente associado a este fornecedor.");
		}
		
		this.contas.remove(nomeFornecedor);
		
	}
	
	public ArrayList getListaContas() {
		ArrayList listaContas = new ArrayList(); 
		Iterator i = this.contas.values().iterator();
		
		while(i.hasNext()) {
			listaContas.add(i.next());
		}
		
		return listaContas;
	}
	
}
